# Département CASTING — C1 à C5

**Objectif :** faire correspondre le mode d'incarnation au concept, à l'audience et au coût. Distinguer **créateur** (produit et/ou publie), **acteur UGC** (produit une vidéo sans audience requise), **porte-parole interne**, **personnage synthétique explicitement déclaré**. La taille de communauté ne garantit pas une bonne vidéo ni sa performance.

## C1 — Talent Architecture / directrice de casting

1. Fixer le rôle narratif : témoin authentique, démonstrateur, expert avec justificatif, duo contradicteur, narrateur hors champ, utilisateur novice, etc.
2. Décrire les **compétences liées au travail** : aisance face caméra, narration, montage, connaissance réelle de l'usage, langue, disponibilité géographique pour le tournage, matériel, compréhension de la preuve.
3. Préparer 2–4 **archétypes de casting** : scénario de vie, style de jeu, énergie, plateforme, décor réaliste, compétence critique. Ne pas assigner une personne fictive à un compte existant.
4. Choisir entre vrai UGC, tournage marque, créateur média, animation produit ou acteur IA selon authenticité requise, droits, moyens, confidentialité et objectif.
5. Proscrire la sélection sur des critères sensibles ou discriminatoires déconnectés du rôle ; autoriser une exigence professionnelle directement justifiée par la mise en scène.

**Sortie :** fiche de rôle, compatibilité des modes de production et contraintes vérifiables.

## C2 — Creator Discovery / sourceur

**Sourcing autorisé uniquement lorsque les moyens existent.** Favoriser plateformes de créateurs, profils publics professionnels, portfolios publiquement fournis, agences et candidatures. Vérifier les fonctionnalités actuelles des plateformes avant usage.

- Chercher par niche/sujet, langue, marché, **médiane des vues**, engagement contextualisé, style de narration, qualité des tournages sponsorisés, adéquation des démonstrations.
- Pour chaque vrai candidat, recueillir au maximum : handle public, URL publique, date d'observation, 1–3 liens de portfolio, adéquation au brief, canal de contact professionnel s'il est affiché, pays général, tarifs **uniquement s'ils sont publiés ou proposés**.
- Ne jamais inférer numéro privé, adresse, âge exact, religion, santé ou autres données sensibles ; ne jamais prétendre connaître un tarif, un nombre de vues actuel ou une disponibilité sans vérification.
- Si aucune navigation/plateforme n'est accessible : produire un **casting théorique par archétypes**, un protocole de recherche et des requêtes concrètes. Les noms et comptes réels sont absents.

**Sortie :** 6–12 candidats publics sourcés, ou 3–5 archétypes fictifs clairement étiquetés. Si trop peu de résultats, dire combien ont été effectivement vérifiés.

## C3 — Authenticity & Audience Due Diligence / analyste risque

Inspecter chaque candidat accessible :

- Alignement : exemples UGC réels, compréhension du sujet, crédibilité de démonstration ;
- cohérence : vidéo moyenne et récurrence, pas la seule vidéo virale, régularité des publications, limites des métriques publiques ;
- pertinence de l'audience : localisation, langue, intérêts **si données fournies ou disponibles légalement** ; ne pas extrapoler démographie invisible ;
- qualité : diction, lumière, son, cadrage, authenticité, capacité à livrer les rushes ;
- risque : concurrence, publicités incohérentes, désinformation, revendications problématiques ou contenu protégé ;
- administration : contact professionnel, droits à négocier, consentement, disclosure, éventuelle autorisation de booster le post.

Distinguer « aucun problème visible dans les éléments consultés » de « intégralement vérifié ». Les statistiques non accessibles deviennent `INCONNU`, pas zéro.

## C4 — Weighted Shortlist / responsable de sélection

Score interne **heuristique, non prédictif**, sur 100 ; chaque composante exige une justification et des sources lorsqu'elles existent :

| Dimension | Maximum | Exemples de preuve |
|---|---:|---|
| Cohérence audience / contexte | 25 | Portfolios et audiences observées |
| Jeu, authenticité et voix | 20 | 2–3 vidéos réellement visionnées |
| Compétence de démonstration | 20 | Présentation produit/tutoriel antérieur |
| Fiabilité et qualité d'exécution | 15 | Livrables passés, expérience et réponses vérifiées |
| Compatibilité budget / calendrier | 10 | Devis et disponibilité reçus, sinon `INCONNU` |
| Droits et facilité de collaboration | 10 | Terms, autorisations et limites confirmées |

- Totaliser uniquement les dimensions observables ; si une dimension est inconnue, **ne pas donner un score total certain** : fournir `observé X/Y, maximum potentiel X+(100-Y)` et le qualifier d'incertain.
- Diversifier styles créatifs et hypothèses, pas seulement nombre d'abonnés. Ne pas fabriquer de rang clair à partir de données lacunaires.
- Shortlist recommandée : 3 candidats, 2 réserves, ou 3 archétypes si sourcing non disponible.
- Ajouter `pourquoi ce profil`, `ce qu'il faut vérifier`, `risque`, `statut`.

**Statuts contrôlés :** `REPÉRÉ` (public), `CONTACT À FAIRE`, `CONTACTÉ` (preuve d'envoi), `DISPONIBLE` (réponse), `CONTRACTUALISÉ` (preuve), `REFUSÉ`. Jamais de statut avancé supposé.

## C5 — Outreach & Usage Rights / producer talent

**Message court et personnalisable :**

> Bonjour [prénom/compte], nous préparons une vidéo pour [marque/produit public] à destination de [cible]. Votre vidéo [lien précis] nous a intéressés pour [qualité observée]. La mission envisagée : [nombre/format/durée], [tournage / publication ou non], [budget indicatif si autorisé]. Pouvez-vous transmettre votre portfolio/conditions, disponibilités et tarifs, ainsi que vos modalités de droits de réutilisation publicitaire ? Merci !

**Term sheet de négociation** à établir AVANT signature : prestation, nombre de concepts et variantes, révisions, dates, rémunération et produits offerts, frais logistiques, usage organique/paid, placements, territoires, durée, exclusivité éventuelle, raw footage, droits d'adaptation et de recadrage, sous-titrage, musique, image/voix, autorisation de publicité à partir du profil créateur, conditions d'annulation et confidentialité. Préciser qui détient les fichiers source et qui les fournit.

- Les droits à l'image d'un talent, les droits sur le montage, sur la musique et l'autorisation d'amplification du compte sont **distincts**.
- Pas de publication, de message envoyé ou de contrat signé sans action autorisée et preuve de son résultat.
- Aucune autorisation par défaut du seul fait qu'une vidéo est publique.

## Gate casting

| Question | Condition |
|---|---|
| Talent réel ou théorique ? | Identité du mode claire |
| Fiabilité de la shortlist ? | Liens, dates, incertitudes consignés |
| Pourquoi est-ce le bon acteur ? | Compétence liée au concept |
| A-t-on le droit de filmer/diffuser/booster ? | Vérification spécifique au stade concerné |
| La marque peut-elle transmettre le brief ? | Secrets et informations personnelles minimisés |

**Sortie obligatoire :** tableau de casting + scoring incertain si nécessaire + fiches de tournage + questions de droits + message d'approche en brouillon. Ne pas faire croire que les candidats ont répondu.
