# Département BRIEF — B1 à B5

**But :** transformer une offre documentée en hypothèses créatives tournables. Chaque fonction produit une décision et un artefact transmis au pôle suivant. Ne pas confondre arguments marketing et faits vérifiés.

## B1 — Product Intelligence / analyste offre

**Entrées :** URL publique, description, application, photos, prix, démonstration, CGV, statut de lancement et preuves. **Exécution :**

1. Relever la catégorie, le mécanisme concret, les usages, les limites, les alternatives, les prérequis et la disponibilité réelle.
2. Documenter la chaîne `fonctionnalité → capacité concrète → conséquence utilisateur → bénéfice émotionnel` sans présenter une déduction comme une preuve.
3. Comparer l'annonce à ce que vit le client sur la page de destination. Ne pas annoncer une fonction prototype comme déjà disponible.
4. Créer un **registre des claims** : `ID`, affirmation formulable, type (objectif/subj./prix/délai/comparatif/environnemental/témoignage), source, date, statut `VERIFIED / PENDING / REJECTED`, limites.
5. Interdire les superlatifs (« le meilleur », « garanti », « numéro 1 », « gratuit ») sans preuve adaptée ; ne pas transformer des économies hypothétiques en résultats.

**Livrable :** résumé produit en 120 mots ; 5 bénéfices max ; trois limitations ; registre d'allégations ; trois démonstrations possibles. **Vérification :** produit et bénéfice ne reposent pas sur des promesses générales.

## B2 — Audience & Voice of Customer / analyste recherche

**Entrées :** analytics et retours client disponibles, commentaires publics, FAQ, tickets anonymisés, études, concurrents. **Exécution :**

1. Repérer les situations où le problème devient important : moment déclencheur, tâche échouée, solutions déjà tentées et émotions associées.
2. Chercher, si outils autorisés, 5–10 signaux concrets d'usages ou objections (FAQ, verbatims consentis, documentation, avis) en distinguant la représentativité.
3. Comparer 3–5 alternatives réelles seulement si vérifiables ; consigner **angle publicitaire**, pas copying exact de slogans ou contenus protégés.
4. Produire une matrice `besoin × objection × preuve × message × contenu filmable`.
5. Noter les limites : commentaires publics ≠ échantillon représentatif ; observation ≠ étude causale ; données sociales ≠ autorisation de traiter les données privées.

**Livrable :** 5 « paroles client » paraphrasées et sourcées (jamais fabriquées comme citations exactes), 5 objections, 3 patterns concurrentiels, 3 opportunités de différenciation.

## B3 — Segmentation & JTBD / stratège cible

**Exécution :**

1. Définir les segments selon **contexte/besoin/comportement** plutôt que critères physiques ou attributs protégés.
2. Pour chaque segment, décrire le job fonctionnel, émotionnel et social, moment d'achat, alternatives, freins, message, plateforme probable (hypothèse si donnée absente).
3. Qualifier l'urgence du problème, le prix acceptable **à valider**, la confiance nécessaire et la preuve qui ferait changer d'avis.
4. Hiérarchiser selon `gravité du besoin`, `preuve disponible`, `accessibilité créative`, `alignement avec l'objectif` avec 4 notes de 0 à 5, explicitement heuristiques.
5. Choisir une cible principale et un segment secondaire. Ne pas écrire une pub qui s'adresse simultanément à des audiences aux motivations incompatibles.

**Livrable :** 2 à 4 mini-personas comportementaux et une seule cible prioritaire par script.

## B4 — Positionnement & territoires / directeur de stratégie

**Exécution :**

1. Formuler : « Pour [situation], [offre] aide à [résultat observable] en [mécanisme], à la différence de [alternative] ». Corriger si la différence n'est pas prouvée.
2. Distinguer trois axes : `preuve immédiate` (démonstration), `tension humaine` (émotion), `renversement` (contre-intuition, sans piège).
3. Adapter la **promesse**, le **ton** et le **niveau de friction** aux attentes d'une audience en découverte ou d'une audience déjà informée.
4. Choisir un symbole reconnaissable et un geste filmable propre à l'offre ; ne pas copier scènes ou musique d'une campagne précise.
5. Définir pour chaque territoire une idée directrice, un obstacle narratif, une révélation, un CTA et un risque de compréhension.

**Livrable :** un message dominant en une phrase, 3 directions créatives distinctes et leurs hypothèses.

## B5 — Creator-Ready Brief / responsable de campagne

**Brief à adresser au créateur** (transmissible sans fuite de données) :

- contexte de la marque et de l'offre, disponibilité honnête ;
- cible et comportement final souhaité ;
- promesse prouvable, preuves autorisées et vocabulaire à éviter ;
- angle et **émotion à transmettre**, sans imposer une récitation mécanique ;
- 3 éléments à montrer absolument, 3 erreurs à éviter ;
- exigences de format et plateforme, nombre de hooks, variantes et durée cible ;
- plan principal + plans de sécurité (B-roll, capture d'écran, gros plan produit) ;
- obligations éventuelles de transparence publicitaire, publicité IA, sous-titrage ;
- livrables (rushes, sous-titres, fichier sans musique, voix seule, montage, ratio), nombre de retours ;
- autorisations (personnes, lieux, musique, paid usage, exclusivité éventuelle), dates de validation ;
- budget plafond, statut non engagé et critères d'acceptation.

**Liberté encadrée :** séparer `OBLIGATOIRE` (vérité, preuve, légalité, CTA, produit visible) de `FLEXIBLE` (intonation, vocabulaire courant, style de prise de vue). Un bon UGC ne doit pas sembler lu ; laisser le créateur reformuler sans changer les faits.

## Gate brief : matrice de passage

| Question | Condition de sortie |
|---|---|
| Pourquoi cette publicité existe-t-elle ? | Objectif et CTA visibles |
| À qui parle-t-on ? | Une cible principale et un contexte |
| Quel bénéfice est filmable ? | Démo ou bénéfice observable |
| Pourquoi le croire ? | Au moins une preuve crédible ou claim retirée |
| Qu'est-ce qui doit rester vrai ? | Disponibilité, prix, limites, droits décrits |
| Est-ce transmissible à un créateur ? | Fichier B5 sans secret superflu |

**Si échec :** noter le blocage, produire une variante sûre et maintenir la campagne au stade « stratégie non validée ». Ne jamais laisser une accroche spectaculaire masquer une absence de preuve.
