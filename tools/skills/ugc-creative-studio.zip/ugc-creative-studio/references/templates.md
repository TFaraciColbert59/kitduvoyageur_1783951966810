# Contrat de livrable — UGC Creative Studio

L'artefact est un **dossier de campagne concret**, pas une liste de conseils vagues. Utiliser des sous-titres Markdown stables, attribuer des identifiants aux claims (`CL-01`) et hooks (`HK-01`). Les labels `[VÉRIFIÉ]`, `[FOURNI CLIENT]`, `[HYPOTHÈSE]`, `[À CONFIRMER]` et `[PROPOSITION]` évitent le blanchiment d'incertitude.

## Répertoire d'une campagne `full`

```text
campaigns/<campagne>/
├── 01_BRIEF.md
├── 02_CASTING.md
├── 03_CONCEPTS.md
├── 04_SCRIPTS.md
├── 05_STORYBOARD.md
├── 06_QA.md
├── 07_TEST_PLAN.md
└── manifest.json
```

### 01_BRIEF.md

Inclure dans cet ordre : `# Identification`, `## Statut produit`, `## But/CTA`, `## Factbook & preuves`, `## Cibles/JTBD`, `## Insights/objections`, `## Positionnement`, `## Trois territoires`, `## Brief créateur`, `## Inconnues/bloquants`. Chaque preuve a un lien (public ou référence interne accessible autorisée) et date. Séparer preuve technique, perception client, idée créative.

### 02_CASTING.md

Sections : `## Mode de production`, `## Archétypes`, `## Méthode de sourcing`, `## Candidats réels vérifiés OU archétypes fictifs`, `## Tableau de scores et inconnues`, `## Shortlist`, `## Brouillons d'approche`, `## Questions contractuelles et autorisations`. Pour chaque candidat réel : lien de profil, portfolios sourcés, statut et date de consultation. Pas d'URL inventée.

### 03_CONCEPTS.md

Sections : `## Concepts A/B/C`, `## Hook bank`, `## Concept retenu et pourquoi`, `## Variantes indépendantes`, `## Risques/retours red team`. Chaque hook : texte exact, visuel première image, émotion, mécanisme de preuve, coût/difficulté, claim ID.

### 04_SCRIPTS.md

Sections : `## Hypothèses de débit`, `## Script 15 s`, `## Script 30 s`, `## Script 60 s`, `## Variantes hooks/CTA`, `## Claims & wording à vérifier`, `## Sous-titres`. Si une durée n'est pas demandée, l'indiquer et conserver au moins une version complète. Les scripts peuvent être minutés mais une **répétition** doit valider la durée réelle.

### 05_STORYBOARD.md

Sections : `## Storyboard plan par plan`, `## Shotlist condensée`, `## Décor/lumière/son`, `## Props/écrans/tenues`, `## Variantes et plans B`, `## Instructions montage`, `## Exports`, `## Droits & dépendances`, `## Estimation des coûts (hypothèses/devis)`. Tableau storyboard : TC, cadre, action, dialogue/VO, texte, audio, preuve, asset, risque, plan B.

### 06_QA.md

Sections : `## Décision et stade`, `## Score éditorial/100`, `## Critique des hooks`, `## Allégations`, `## Droits et disclosures`, `## QA technique/plateforme`, `## Bloquants`, `## Correctifs/propriétaires/preuves de clôture`, `## Éléments non vérifiés`. Tout `GO_DIFFUSION` suppose une vidéo réellement contrôlée, la conformité vérifiée et une validation humaine explicite.

### 07_TEST_PLAN.md

Sections : `## Hypothèses`, `## Variantes/contrôle`, `## Ce qui reste constant`, `## KPIs et méthode de collecte`, `## Limites d'attribution`, `## Budget et fenêtre d'observation`, `## Critères de décision`, `## Tableau d'itérations`. Chiffres KPI = mesures, jamais projections présentées comme acquises.

## Schéma de `manifest.json` (version 1)

Le fichier suivant est un **exemple de structure**, pas une campagne prête à publier. Les chemins `artifacts` sont relatifs au dossier de campagne. Utiliser `not_applicable` uniquement avec une raison précise et vraie.

```json
{
  "schema_version": 1,
  "campaign_id": "campagne-exemple",
  "market": ["FR"],
  "objective": "inscriptions",
  "production_method": "brand_owned",
  "creative_score": 82,
  "artifacts": {
    "brief": "01_BRIEF.md",
    "casting": "02_CASTING.md",
    "concepts": "03_CONCEPTS.md",
    "scripts": "04_SCRIPTS.md",
    "storyboard": "05_STORYBOARD.md",
    "qa": "06_QA.md",
    "test_plan": "07_TEST_PLAN.md"
  },
  "claims": [
    {
      "id": "CL-01",
      "text": "Le produit permet de préparer une liste de tâches",
      "status": "pending",
      "used_in_scripts": false,
      "evidence": "Captures du prototype à comparer à la version publique",
      "source_ref": "Dossier interne non encore vérifié"
    }
  ],
  "claim_free_reason": "",
  "clearances": {
    "talent_release": {"status": "pending", "evidence": "En attente de signature"},
    "usage_rights": {"status": "pending", "evidence": "Licence publicitaire à négocier"},
    "media_rights": {"status": "pending", "evidence": "Inventaire des assets à compléter"},
    "music_rights": {"status": "pending", "evidence": "Choix musical non arrêté"},
    "ad_disclosure": {"status": "pending", "evidence": "Mentions à confirmer selon canal"},
    "ai_transparency": {"status": "not_applicable", "evidence": "Aucun média synthétique prévu à ce stade"},
    "platform_policy": {"status": "pending", "evidence": "Contrôle de placement non effectué"},
    "brand_approval": {"status": "pending", "evidence": "Validation du commanditaire non reçue"},
    "final_visual_check": {"status": "pending", "evidence": "Vidéo non tournée"},
    "landing_page_check": {"status": "pending", "evidence": "URL finale à vérifier"}
  },
  "final_video": null
}
```

## Statuts et décisions

- `verified` : preuve identifiée et examinée **par un humain/agent autorisé**, source/ref et date dans l'artefact. Le script de contrôle teste seulement la **structure**, jamais la véracité intrinsèque.
- `pending` : pas prêt, ne pas diffuser.
- `rejected` : contradiction ou refus, corriger avant progression.
- `not_applicable` : exception argumentée dans `evidence`, jamais utilisée pour esquiver un droit nécessaire.
- `--goal preproduction` : vérifie structure/artefacts/claims critiques ; ne signifie pas que les droits de diffusion sont acquis.
- `--goal publish` : vérifie en plus toutes les clearances et la présence d'un fichier vidéo local. Un passage au vert signifie `STRUCTURE VALIDÉE SOUS RÉSERVE D'EXAMEN HUMAIN`, pas une autorisation légale ou de plateforme.

### Commande de contrôle (facultative)

```bash
python3 ~/.claude/skills/ugc-creative-studio/scripts/verify_campaign.py campaigns/campagne-exemple --goal preproduction
python3 ~/.claude/skills/ugc-creative-studio/scripts/verify_campaign.py campaigns/campagne-exemple --goal publish
```

**Contrainte honnête :** si la campagne n'a pas encore de créateur confirmé ou de vidéo, la `clearances` reste `pending` et l'annonce ne peut pas être dite publiée ou prête à publier.


## Extension optionnelle « vidéo réellement rendue »

Lorsque P5 produit une animation ou un montage MP4, compléter le dossier de campagne (sans supprimer les 7 fichiers de base) :

```text
campaigns/<campagne>/
├── 08_QA_RENDER.md       # Défaillances à timecode et résolution
└── video/
    ├── creative-spec.md  # Brief d'animation exploitable
    ├── timeline.json     # Découpage calculable et validé
    ├── scene.html        # HTML autonome avec window.renderAt(t)
    ├── score.wav         # Audio original si présent et autorisé
    ├── stills/           # Captures 0%, 25%, 50%, 75%, 99%
    └── final.mp4         # N'existe qu'après rendu réellement réussi
```

Dans `manifest.json`, conserver `schema_version: 1` et ajouter facultativement :

```json
"video_pipeline": {
  "mode": "code_video",
  "status": "rendered_not_approved",
  "width": 1080,
  "height": 1920,
  "fps": 30,
  "duration_seconds": 15,
  "scene": "video/scene.html",
  "technical_report": "08_QA_RENDER.md",
  "rendered_file": "video/final.mp4",
  "assets_rights_checked": false
}
```

Mettre à jour `final_video` **seulement** lorsque le fichier existe sur disque. `rendered_not_approved` n'autorise pas la diffusion. Si rendu impossible, `status: blocked_render`, `rendered_file: null` et motif documenté. `video_pipeline` ne contourne jamais les dix `clearances` existantes.
