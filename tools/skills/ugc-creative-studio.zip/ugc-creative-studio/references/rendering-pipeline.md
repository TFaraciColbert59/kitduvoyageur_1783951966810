# Studio de rendu vidéo — Playbook production native Claude Code

**Objectif :** permettre à Claude de créer **effectivement** des MP4 à partir de scènes animées en code, tout en conservant B1–B5, C1–C5, P1–P5, Q1–Q5. Le rendu est une capacité de **P4/P5**, suivie d'une vérification **Q4/Q5**, et non un 21e skill.

## 0. Sélectionner la bonne technique AVANT d'écrire le code

| Mode | Ce qui peut être livré | Limites et décision |
|---|---|---|
| `code_video` (par défaut pour motion design, infographie, animation stylisée, démo UI) | HTML/SVG/Canvas/JS → images Chrome → MP4 FFmpeg, musique originale en WAV | Produit vraiment un fichier vidéo si Chrome/Node/FFmpeg accessibles. **Ne fait pas de vrais visages filmés**. Préférer SVG/Canvas pour typo nette, WebGL pour 3D. |
| `real_ugc` | Script + shotlist + rushes réels autorisés + montage FFmpeg | Acteur/créateur réel et vrais rushes requis. Ne simule jamais un témoignage vécu. |
| `hybrid` | Vidéo réelle ou clips IA autorisés + couches vectorielles, sous-titres, son, montage FFmpeg | Dépend de vidéos/images disposant de droits et du consentement des personnes. |
| `concept_only` | Brief, script, storyboards, prompts de tournage/génération | Si aucun moteur/asset n'est disponible, **aucun MP4 revendiqué**. |

Le **casting UGC** C1–C5 reste indispensable si la campagne utilise un créateur réel ; en `code_video`, le casting sélectionne un *type de narrateur, personnage graphique ou voix* et mentionne explicitement l'absence de créateur UGC filmé. Ne pas appeler « témoignage client » une prestation interprétée ou synthétique.

## 1. Audit de machine / droits / budget

- `node --version` (**Node 22+** pour le renderer sans dépendance), `ffmpeg -version`, `ffprobe -version`, vérifier Chrome ou Chromium local. Sur macOS, Chrome est généralement dans `/Applications/Google Chrome.app/Contents/MacOS/Google Chrome`.
- Aucun package npm supplémentaire n'est requis pour le pipeline intégré. **Aucun abonnement vidéo IA n'est requis** pour le motion design codé. Claude Code et le modèle choisi ont leurs propres conditions et quotas.
- Ne jamais installer/cloner sans nécessité. `Remotion`, `Blender`, `Manim`, `Three.js` ou `Puppeteer` sont des options distinctes, uniquement avec autorisation pour leurs dépendances et leur licence.
- Vérifier droits de chaque voix, musique, échantillon, visage, police, pack d'images et logo. Aucun clone de voix, faux client ou vidéo d'un influenceur empruntée sans droits.
- `code_video` ne prétend pas créer une scène photoréaliste de vraies personnes à partir de vecteurs. Si l'histoire nécessite un humain à l'écran, basculer vers `real_ugc` ou `hybrid` ; identifier ce qui manque.
- **Confidentialité :** HTML et audio originaux rendus localement ; les outils ne contactent pas d'API externe. Ne pas utiliser d'assets liés à un CDN. Réviser les fichiers locaux avant exécution, et ne pas inclure de secrets de projet dans le HTML.

## 2. Design & storyboard calculable

Livrer avant codage :

1. `creative-spec.md` : objectif, audience, CTA, format et durée, direction artistique, palette/typo, nature des plans et preuves autorisées.
2. `timeline.json` : segments `start_s/end_s`, `visual`, `text`, `voiceover`, `sfx`, `claims`, `assets` et `transition`, sans trous ni chevauchement non justifié ; un message clé par scène.
3. `scene.html` autonome, avec la fonction déterministe `window.renderAt(seconds)` ; **elle doit redessiner intégralement** le cadre à chaque `t` (pas de dépendance à l'image précédente). Toutes les ressources nécessaires doivent être intégrées au HTML (inline SVG, JS, data URLs autorisées). Le renderer insère le HTML via le protocole Chrome, et **bloque HTTP/HTTPS** : les ressources relatives et CDNs ne fonctionnent pas dans ce mode.
4. `audio/score.wav` : partition originale codée ou média existant correctement licencié ; narration et SFX dans une piste mixée unique. Prévoir intelligibilité des dialogues et volume réduit de musique sous la voix ; jamais d'assertion de normalisation si non mesurée.
5. `assets-rights.md` : inventaire individuel, licence, source et autorisation publicité payante.

### Règles de dramaturgie

- **0–2 secondes** : contraste/hook visuel + texte compris sans son (éviter intro logo longue).
- **2–5 secondes** : idée et contexte présentés.
- **5–12 secondes** : démonstration, preuve ou tension narrative (pas de chiffres inventés).
- **Dernière partie** : résolution et **CTA unique**, lisible.
- Tolérer variations de temps/durées, pas une grille rigide à toutes les campagnes.
- Les 15/30/60 s doivent être **réécrites**, pas simplement accélérées ou étirées.
- Gestion 9:16 : mettre le texte important au centre utile (contrôler l'UI réelle de chaque plateforme), contraste accessible, sous-titres, zone de sécurité autour des overlays.
- Planifier la lisibilité mobile à la taille finale. Photographier des preuves réelles si nécessaire : un chiffre vectoriel n'est pas une preuve.

## 3. Contrat JavaScript de la scène

`window.renderAt(t)` reçoit le temps **absolu en secondes**. Il peut retourner une Promise. Il doit :

- dessiner toute l'image à chaque appel indépendamment de la frame précédente ;
- calculer easing, trajectoires, changements de plans et particules à partir de `t` et d'une seed fixe ;
- permettre le rendu aléatoire d'une frame `t=8.2` avant `t=0`, sans différences de visuel ;
- ne jamais utiliser `Date.now`, `performance.now`, `requestAnimationFrame`, `setInterval` ou `Math.random` non seedé pour l'état de l'animation ;
- éviter les APIs externes et rester compatible avec le moteur Chrome du poste ;
- ne pas appeler de sous-processus, ne pas lire les secrets de l'environnement.

**Exemple effectif :** `examples/motion-demo/index.html`. Pour plus de styles, consulter `references/visual-style-library.md` ; ne pas copier directement du code tiers sans revue de licence.

## 4. Rendu local MP4 (aucune dépendance npm)

Depuis le dossier du skill installé :

```bash
# 1. Audio de démonstration original optionnel
python3 scripts/generate_audio.py --output /tmp/ugc-score.wav --seconds 10 --seed 123 --bpm 100

# 2. HTML autonome → Chrome capture à t=i/fps → FFmpeg H.264 MP4
node scripts/render_video.mjs examples/motion-demo/index.html \
  --output /tmp/ugc-demo.mp4 --width 540 --height 960 \
  --fps 24 --duration 10 --audio /tmp/ugc-score.wav \
  --stills /tmp/ugc-frames

# 3. Contrôle technique indépendant
python3 scripts/inspect_video.py /tmp/ugc-demo.mp4 \
  --width 540 --height 960 --fps 24 --duration 10 --require-audio --json
```

`--overwrite` est volontairement **désactivé** : seul un utilisateur ou agent autorisé peut le demander pour remplacer un résultat. La sortie JSON `RENDERED_NOT_APPROVED` signifie que l'encodage a réussi, **pas** qu'une publicité est approuvée.

**Fonctionnement :** Node 22 ouvre Chrome headless sur un profil éphémère, injecte la scène HTML dans un onglet vierge, appelle `window.renderAt(t)` pour chaque image, récupère un PNG via Chrome DevTools Protocol et l'envoie directement à FFmpeg par stdin (`image2pipe`). FFmpeg produit H.264 `yuv420p` avec AAC si piste audio. Le pipeline évite de stocker des milliers de PNG ; `--stills` enregistre cinq vignettes de référence. Les outils ne nécessitent ni compte API ni connexion Internet.

**Rendu final recommandé :** vertical 1080×1920 à 30 fps, H.264/AAC MP4 (à adapter au placement). Pour itérer rapidement : preview **540×960 / 24 fps**. Pour une composition horizontale : 1920×1080, pour 1:1 : 1080×1080. 60 fps uniquement s'il apporte réellement une amélioration perceptible. Les rendus WebGL lourds exigent davantage de puissance et peuvent échouer avec GPU virtuel ; replier vers Canvas 2D ou rendu Blender hors du pipeline intégré.

## 5. Audio et synchronisation

- Générer les événements de la piste audio selon **le même temps t** que les séquences visuelles : beats, CTA, transitions, silences et phonèmes de narration, consignés dans la timeline.
- Le générateur `generate_audio.py` produit un court lit musical **original** déterministe, sans bibliothèque externe. Ce n'est pas un simulateur de musique commerciale ni un moteur de composition sophistiqué. Pour musique élaborée, écrire une composition originale et vérifier les droits des éventuels samples.
- Pour voix off, utiliser un enregistrement autorisé ou TTS autorisé ; tracer consentement, langue, texte exact et licence. Ne jamais créer la copie d'une voix réelle sans droit.
- Si dialogue + score, mixer avant l'export final ; en cas de multi-pistes, vérifier décalages, clipping et niveaux via FFmpeg. Ne pas supposer que la musique codée est « utilisable commercialement » si elle inclut des samples sous licence externe.
- Les sous-titres doivent correspondre aux paroles **réellement entendues** ; le rendu sans audio est possible, mais ne pas inventer une voix-off inexistante.

## 6. Validation itérative, en 3 gates

**Gate 3a / avant rendu (P5)** : brief validé, storyboard / timeline complets, claims appuyées, autorisations pour assets, choix render_mode, budget/plafond, environnement vérifié. Si blocage factuel, modifier le texte avant le rendu.

**Gate 3b / après rendu technique** : `inspect_video.py` valide codec/dimensions/fps/durée/audio attendu. Vérifier les cinq stills, puis les transitions sensibles et le début/fin du MP4 avec lecture réelle. Contrôler : marges et sous-titres, typographie, calques, anti-aliasing, images noires involontaires, frames bloquées, fluidité, artefacts, contraste, musique/voix, CTA, logo. Ne pas noter la fluidité d'après des vignettes : regarder le MP4.

**Gate 4 / avant diffusion (Q3–Q5)** : relecture indépendante (une seconde IA si disponible, sinon critique contradictoire explicite) ; produire un rapport `08_QA_RENDER.md` avec observations ponctuelles (`timecode`, problème, gravité, correctif, preuve d'amélioration) ; réviser la scène et rerendre ; documenter les itérations. Les critères de décision juridiques et humains demeurent **séparés** du résultat technique.

*Méthode de revue « indépendante »* : le juge reçoit le brief, la timeline, les stills et la vidéo, mais **pas** l'argumentaire apologétique de l'auteur. Score indicatif : hook 20, cohérence 15, graphisme 15, lisibilité 15, rythme 15, synchronisation 10, CTA 10. Exigence recommandée : aucun défaut bloquant, 80/100 éditorial ou revue corrective ciblée. Score subjectif, **pas** une mesure publicitaire.

## 7. Alternatives et plan de repli

- Si le navigateur interdit les captures / si codecs manquants : livrer `scene.html`, la timeline, la piste WAV et les scripts, avec statut `BLOCKED_RENDER` et raison exacte, sans faux MP4.
- Si assets locaux externes nécessaires : les embarquer dans le HTML avec data URLs sous contrôle de taille et de licence, ou **adapter après revue** le moteur pour un serveur local sécurisé. Le mode livré bloque les URLs HTTP(S) et n'accède pas au système de fichiers depuis la page.
- Si projet a déjà **Remotion** ou **Blender**, ne pas dupliquer l'infrastructure ; utiliser son moteur natif pour le rendu en respectant le contrat de timing, de QA et de preuve.
- Pour prise de vue réelle : livrer un dossier de tournage et assembler les rushes autorisés par FFmpeg, sans appeler un UGC synthétique « client ».
- Si Chrome Code exécute dans un environnement sans GUI, Chrome headless reste possible. Si le logiciel n'est pas disponible, aucun succès ne peut être revendiqué.

## 8. Indicateurs d'efficience

Noter `duration_s`, `fps`, `frames`, dimensions, codec, taille du MP4, nombre de rerenders, erreurs et si audio existe. Mesurer temps de génération et coût réel uniquement si des logs existent, jamais de vitesse ni prix inventés. Préférer rendu preview, revue des points critiques, corrections locales et seulement ensuite le 1080p final.
