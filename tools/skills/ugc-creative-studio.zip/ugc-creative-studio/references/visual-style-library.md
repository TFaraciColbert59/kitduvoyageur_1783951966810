# Direction artistique — 15 familles de motion design et corpus externes

Cette bibliothèque est un **outil de choix stylistique**, non un ensemble d'actifs à réutiliser sans autorisation. Chaque référence GitHub est facultative : inspecter sa licence, ses dépendances, ses assets, son historique et le périmètre de réutilisation avant une installation ou une copie. Les comptes d'exemples évoluent et les chiffres ci-dessous reflètent les README consultés le 08/11/2026.

## Sélecteur : 15 familles exploitables sans multiplier les skills

| Style | Effet recherché | Bon usage | Risque de rendu |
|---|---|---|---|
| 01 Flat vector | clarté, démo produit | application / SaaS / pub pédagogique | faible |
| 02 Swiss grid / typographie cinétique | rigueur, impact du hook | chiffres sourcés, CTA | faible |
| 03 Papier découpé / collage | souvenir, partage, émotion | histoire personnelle de marque | moyen |
| 04 Line art / whiteboard | démonstration étape par étape | tutoriel, comparatif honnête | faible |
| 05 Isométrique 2.5D | système, mécanisme, logistique | fonctionnalité, parcours | moyen |
| 06 Glass / halo lumineux | esthétique premium, interface | reveal de produit digital | moyen |
| 07 Pixel art | nostalgie, jeu, communauté | teaser créatif, campagne culture | faible |
| 08 Cyberpunk HUD | techno, données, intensité | concept de tech expérimental | moyen |
| 09 80s synthwave / VHS | nostalgie, énergie | campagne décalée | faible |
| 10 Bauhaus géométrique | graphique, rythmé, mémorable | annonce / identité visuelle | faible |
| 11 Liquid morphing | fluidité, transformation | avant-après *vérifiable* | moyen |
| 12 Aquarelle / dessin vivant | émotion, narration | storytelling, inspiration | élevé |
| 13 Typo sous-titres verticale | proximité, mobile-first | montage d'interview UGC réel | faible |
| 14 3D / WebGL | volume et matière, démonstration d'objet | objets/maquettes 3D autorisés | élevé |
| 15 Data documentary | preuve, transparence, pédagogie | explainer avec sources à l'écran | moyen |

Chaque direction doit préciser **Creative seed** (message, cible, offre, émotion), **Signature features** (palettes, grille, easing, grain, typographie, transitions), **Output** (9:16, fps, durée, écran sûr), **Avoid list**, **Rights**, **Exit CTA**. Un style ne prouve pas le produit ; les données et claims restent sourcées.

## Références inspectées et fonction dans le skill

1. **Awesome Opus 5.5 Videos** — bibliothèque de prompts et d'exemples de scènes codées (README : 703 prompts), utile à P1/P4, **non chargée en automatique** : https://github.com/yihui-dev/awesome-opus5-5-videos
2. **Opus Video Prompts** — 54 cas publics, 18 prompts complets, plusieurs technologies ; inspirations de production, pas des droits acquis : https://github.com/joeseesun/opus-video-prompts
3. **15 Motion Design Styles** — 15 expériences complètes, contrat `window.renderAt(t)`, `rubric.md`, principes de validation croisée, référence directe pour P5/Q4 : https://github.com/Vincentwei1021/mg-styles-15
4. **Lemo Opuscar** — styles de films codés et pipeline image/voix/score, README officiel annonçant **66** styles lors de la consultation (le résumé vidéo évoquait un nombre antérieur), inspiration de styleboard : https://github.com/lemomo-ai/lemo-opuscar
5. **ClaudeAnimationBase** — guide de personnages dessinés et **31 émotions** pour une mascotte *originale* ; ne pas utiliser par défaut la mascotte du dépôt dans une pub de marque : https://github.com/JohnHeibel/ClaudeAnimationBase
6. **Clips musicaux « I'm Upping My P(doom) »** — **cas d'étude**, pas une dépendance ou un dépôt unique. Observer montage/rythme/techniques ; **ne pas réutiliser le morceau ou la vidéo dans une publicité sans droits explicites**. Voir par exemple : https://github.com/JohnHeibel/ClaudeAnimationBase et l'origine de l'exemple vidéo citée par l'utilisateur.
7. **Awesome Claude Opus 5.5 (SandBase)** — index comparatif, tutoriel HTML → MP4 et observations de modèles ; **les benchmarks et tarifs ne sont pas des garanties** : https://github.com/sandbase-lab/awesome-opus-5.5

## Méthode de sélection

1. Définir si le brief demande *personne réelle / film vécu* ou *animation*. Si personne réelle, ne pas choisir `code_video` comme substitut.
2. Sélectionner **une identité principale** et au maximum **une technique secondaire**. Ne pas mélanger 8 styles pour une vidéo de 15 s.
3. Définir six règles testables du style (ex. taille minimum de légende, nombre de couleurs, easing, cadence, fonds, interdits).
4. Produire une **preview 2–4 secondes** et des stills, valider sur taille mobile. Réviser style+texte d'abord, puis rendre toute la durée.
5. Interdire le contenu qui ressemble trompeusement à un film réel, une preuve produit ou un témoignage réel si ce n'est pas le cas.

## Sources techniques / de format

- Claude Skills, frontmatter, progression et arborescence : https://platform.claude.com/docs/en/agents-and-tools/agent-skills/overview
- Rendu alternatif Remotion : https://www.remotion.dev/docs/cli/render
- FFmpeg : https://ffmpeg.org/ffmpeg.html
- Chrome DevTools Protocol : https://chromedevtools.github.io/devtools-protocol/

*Le pack de ce skill ne télécharge, n'installe, n'importe et n'exécute aucun de ces dépôts : il fournit son propre renderer original.*
