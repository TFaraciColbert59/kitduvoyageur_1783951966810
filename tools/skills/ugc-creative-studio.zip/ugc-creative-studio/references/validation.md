# Département VALIDATION — Q1 à Q5

**But :** audit indépendant, sans complaisance ni garantie de performance. L'équipe de validation ne doit jamais être rémunérée fictivement par le résultat ; elle cherche les raisons de l'échec avant d'approuver une dépense. Le droit applicable varie selon marché et média : voir `platforms-compliance.md`.

## Q1 — Creative Strategy Audit / planneur critique

**Questions :**

1. La vidéo a-t-elle une cible unique, un contexte reconnaissable et un désir réel ?
2. Le produit résout-il visuellement le problème posé, ou n'apparaît-il qu'à la fin ?
3. La marque pourrait-elle être remplacée sans perdre de sens ? Si oui, renforcer la preuve distinctive.
4. Chaque claim est-elle vérifiable, ou pourrait-elle induire en erreur ?
5. La promesse et le CTA correspondent-ils à la page d'arrivée et à l'état réel de l'offre ?
6. La fiction est-elle clairement reconnue, le cas échéant, et la situation respecte-t-elle les personnes représentées ?

**Sortie :** diagnostic hiérarchisé `CRITIQUE / MAJEUR / MINEUR` + correction textuelle/visuelle précise, pas une recommandation vague.

## Q2 — Adversarial Hook Review / red team créatif

Pour chaque hook retenu :

- **Test des 2 secondes :** quel est le bénéfice perçu à l'image zéro / sans son ?
- **Test de véracité :** le hook suggère-t-il un résultat, une disponibilité, un témoignage ou une rareté non démontrés ?
- **Test de distinction :** est-ce une accroche générique interchangeable ?
- **Test de rythme :** combien de temps avant de montrer la réponse utile ?
- **Test de mémoire :** qu'est-ce que la personne saura décrire cinq minutes après ?
- **Test de rupture :** quelle raison honnête donne-t-on de rester ?

Noter par critère 0–5 avec justification observable, et proposer pour chaque faible hook un remplaçant mot pour mot + première image. Ne pas inventer des taux de rétention. Distinguer un hook audacieux d'une accroche humiliant ou trompant l'audience.

## Q3 — Truth, Rights & Compliance / responsable conformité

**Bloquants systématiques à vérifier avant diffusion :**

- claim objective ou comparaison non prouvée ; prix, disponibilité, caractéristiques et délais non confirmés ;
- avis client, nombre de clients, historique d'utilisation, « personnellement j'ai testé » fictif ou attribué à une personne qui ne l'a pas dit ;
- lien commercial/placement rémunéré non signalé lorsque requis ;
- acteur, image, voix, lieu, mineur, logo, musique ou contenu tiers sans droits adaptés ;
- droits UGC limités à l'organique alors que l'annonce sera utilisée en paid media ; autorisation distincte de Spark Ads/Partnership Ads non obtenue si nécessaire ;
- personne fictive ou créée par IA présentée comme un vrai client ; obligations de transparence applicables aux contenus IA non satisfaites ;
- catégorie réglementée sans examen spécifique (santé, financier, âge, politique, etc.) ;
- page de destination divergente du discours ou lien non vérifié.

**Travailler par tableau :** `exigence | applicabilité | source officielle actuelle | preuve détenue | responsable | statut VERIFIED/PENDING/NOT_APPLICABLE | impact`. Une case `NOT_APPLICABLE` doit avoir une raison documentée. La validation automatique ne vaut pas avis juridique.

**Exemples pour FR/UE à revérifier :** transparence « publicité »/« collaboration commerciale » de l'influence rémunérée ; mentions relatives à certains visuels de personnes générés par IA ; principes de clarté et d'exactitude. Les exigences exactes changent selon contexte et date : jamais les figer sans contrôle.

## Q4 — Production & Platform QA / ingénieur livraison

**Lecture créative** : 1er frame, intelligibilité à l'écran mobile, texte contrasté, sous-titres complets, recadrage, continuité objets/tenues, crédibilité des scènes, compréhension sans son.

**Lecture technique** : résolution, ratio, orientation, durée, codec/conteneur selon placement, stabilité du niveau audio, absence de clipping, absence de watermark interdit, compatibilité typographique, safe zones testées dans un *aperçu placement réel*, transitions sans flash agressif. Ne pas inventer des marges universelles de pixels qui pourraient changer.

**Lecture de diffusion** : aperçu sur appareil, lecture avec son coupé puis activé, CTA visible, URL/landing page cohérente, consentements et disclosures visibles pendant la durée adéquate.

**Si pas de MP4 ni d'outil d'inspection :** annoter `QA VISUELLE/TECHNIQUE NON EXÉCUTÉE`, fournir plan de test et interdire `READY_TO_PUBLISH`.

## Q5 — Go/No-Go & Experiment Design / directeur qualité + analyste croissance

### Score éditorial 100 points (heuristique, jamais une prévision de performance)

| Dimension | Max | Test |
|---|---:|---|
| Pertinence cible & problème | 15 | Une situation clairement reconnaissable |
| Hook & tension d'ouverture | 20 | Dès les premières secondes, une raison de regarder |
| Démonstration / preuve | 20 | Visuel supportant l'argument central |
| Authenticité & qualité d'incarnation | 15 | UGC crédible, pas script robotique/faux avis |
| Narration, son, lisibilité | 15 | Compréhensible et facile à monter |
| Marque, bénéfice, CTA | 15 | Lien clair avec prochaine action |
| **Total** | **100** | **Score interne subjectif** |

**Interprétation interne :** 85–100 : fort potentiel créatif à TESTER ; 70–84 : corrections conseillées ; moins de 70 : revoir le concept. Ces seuils sont une convention interne de travail, **pas une mesure de rentabilité**. Un seul risque juridique ou droit bloquant entraîne `NO-GO` indépendamment du score.

### Décisions

- `GO_PRÉPRODUCTION` : brief, concept, scripts, casting théorique ou réel et planning exploitables, aucune invention bloquante dans la stratégie.
- `GO_SOUS_RÉSERVES` : créatif prêt, contraintes de tournage/droits encore à lever ; **non diffusable**.
- `NO_GO` : message trompeur, créateur insuffisamment vérifié, droits manquants, script impraticable ou politique non conforme.
- `GO_DIFFUSION` : vidéo finale réellement inspectée, droits et claims vérifiés, obligations de publicité et IA satisfaites, plateforme/pays revérifiés, décision humaine requise obtenue. Le script de validation n'autorise ni ne déclenche une publication.

### Protocole d'expérimentation

1. Émettre une **hypothèse falsifiable** par variante, ex. « une démo dès la première image améliore la rétention à 3 s contre une ouverture en témoignage ».
2. Garder un témoin, changer un facteur majeur à la fois (hook, angle, créateur, durée ou CTA), puis itérer sur gagnants ; si plusieurs facteurs changent, déclarer l'impossibilité d'attribuer la cause.
3. Prioriser les métriques liées à l'objectif : `3s hold`, vue à 25/50/75/100 %, coût par vue, CTR, taux visite→action, CPA et ROAS lorsque traçables ; vérifier définitions propres aux plateformes.
4. Définir `source de données`, `fenêtre d'observation`, `critère d'arrêt`, `budget plafond`, `niveau d'incertitude`, `conditions d'attribution`. Sans taille/puissance suffisante, formuler « signal observé » et non « gagnant prouvé ».
5. Établir l'ordre des retakes selon `impact probable × effort de modification × preuve` plutôt que vouloir tout refaire.
6. Documenter apprentissages y compris résultats négatifs, et conserver copie du visuel + texte exact de chaque variante.

### Compte rendu QA

Répondre obligatoirement :

- **Décision** et stade atteint ; une ligne claire.
- **Raisons** : 3 forces, 3 faiblesses, scores détaillés.
- **Corrections exigées** : description concrète, owner, preuve de clôture.
- **Blocages juridiques/droits** avec statut et source du contrôle.
- **Éléments non évalués** : manque d'accès au montage, au compte, aux données, à la vidéo réelle.
- **Prochain test** : facteur testé, métrique de succès, contrôles.


## Q4/Q5 — Contrôle additionnel du MP4 codé

Une génération locale qui retourne `RENDERED_NOT_APPROVED` n'est **pas** un GO diffusion. Le pipeline effectue d'abord le contrôle **structurel** (`verify_campaign.py`), le contrôle **technique** (`inspect_video.py` / `ffprobe`), puis la revue **visuelle et audio** (cinq stills, échantillonnage transitions, lecture complète obligatoire avant publication). Vérifier au moins : exactitude des claims à l'écran, première seconde, durée exacte du hook, lisibilité mobile et safe zones, sous-titres/voix synchronisés, absence de glitch ou flash indésirable, logo/CTA, cadre, niveaux sonores et licences.

Dans `08_QA_RENDER.md`, consigner `timecode`, `gravité`, `défaut`, `correctif`, `nouvelle preuve` après chaque itération. Le contrôle par un autre agent doit critiquer sans connaître la justification du créateur. La réussite de `ffprobe` ou l'absence de crash ne remplace jamais une lecture humaine du résultat, ni le contrôle Q3 des droits de diffusion.
