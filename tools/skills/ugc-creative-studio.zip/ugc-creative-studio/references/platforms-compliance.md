# Plateformes, droits, transparence — checklists par marché

**Règle supérieure :** ce document rassemble des points de contrôle, pas un avis juridique. Les lois, policies, dimensions techniques et interfaces évoluent. Vérifier auprès de la source officielle **le jour de la livraison** ; indiquer date et URL. Ne pas généraliser les règles françaises au monde entier.

## 1. Matrice selon le type de contenu

| Type | Casting | Témoignage | Identité IA | Droits | Problème typique |
|---|---|---|---|---|---|
| Créateur UGC réel rémunéré | Personne/portfolio authentiques | Seulement si expérience réelle | Non sauf éléments IA | Prestation + image + paid usage + éventuellement boosting | Disclosures, contrat, scripts trop contraints |
| Acteur UGC (sans audience) | Performance et respect du brief | Dire « démonstration » plutôt que faux avis | Non | Image/voix/usage publicité | Fausse revendication « je suis client depuis 2 ans » |
| Salarié/fondateur | Rôle réel vérifiable | Expérience professionnelle vraie | Non | Autorisation appropriée et droit d'utilisation | Promesse produit au-delà de ce qui existe |
| Avatar synthétique | Aucun faux créateur réel | Jamais un faux témoignage authentique | Oui, à divulguer lorsque requis | Licences modèle, voix, visages, sources | Tromperie sur l'existence ou l'expérience du personnage |
| Démonstration produit sans personne | Pas de casting humain | Non | Selon éléments IA | Licence médias, marque et propriété intellectuelle | Démo qui ne correspond pas au produit |

**Ne pas attribuer à une personne des mots qu'elle n'a pas approuvés ni une expérience qu'elle n'a pas vécue.** Une vidéo de marque présentée comme une histoire fictive n'est pas un retour client.

## 2. France : identification publicitaire, preuve, droits

**Références officielles à vérifier :**

- DGCCRF : https://www.economie.gouv.fr/dgccrf/les-fiches-pratiques/promotion-faite-par-les-influenceurs-et-achat-les-reseaux-sociaux
- Légifrance, article 5-2 : https://www.legifrance.gouv.fr/codes/article_lc/LEGIARTI000050457275
- Légifrance, article 5 (visuels modifiés/IA) : https://www.legifrance.gouv.fr/loda/id/JORFTEXT000047663185/
- ARPP Recommandation communication publicitaire numérique : https://www.arpp.org/nous-consulter/regles/regles-de-deontologie/recommandation-communication-publicitaire-numerique/
- Ministère de l'Économie, guide influence : https://www.economie.gouv.fr/guide-bonne-conduite-influenceurs-createurs-contenu

**Actions QA :**

1. Lorsque le contenu relève de l'influence commerciale, signaler clairement l'intention commerciale de manière compréhensible, lisible, immédiatement identifiable ; des mentions telles que « Publicité » / « Collaboration commerciale » peuvent être pertinentes selon l'article 5-2 et le contexte. Éviter une mention noyée dans la description.
2. Contrôler si l'usage d'un visage ou d'une silhouette produits par IA dans le cadre de l'influence commerciale nécessite « Images virtuelles » ou mention équivalente dans le contexte précis (article 5 en vigueur), sans confondre ce cas avec toutes les images de paysage ou toutes les campagnes directes de marque.
3. Vérifier le régime du **contrat écrit** applicable à une relation d'influence commerciale, les seuils et mentions obligatoires au moment de signer ; ne pas extrapoler à toute prestation de tournage.
4. Exiger les preuves des performances, garanties, prix, comparaisons, ventes et caractéristiques susceptibles d'influencer la décision d'achat. Enlever tout claim non vérifié.
5. Vérifier restrictions sectorielles et publicité ciblée auprès de mineurs, promos, réductions, financement et campagnes de prévente, selon la catégorie réelle.

## 3. Union européenne : contenu synthétique et données

- AI Act art. 50 (source officielle) : https://ai-act-service-desk.ec.europa.eu/en/ai-act/article-50
- FAQ Commission UE (application et nuances) : https://digital-strategy.ec.europa.eu/en/faqs/transparency-obligations-under-article-50-ai-act

L'article 50 prévoit notamment des obligations de marquage/divulgation pour certains contenus générés ou manipulés par IA, en particulier les deepfakes. Il s'applique en principe depuis le **2 août 2026** avec règles transitoires ciblées pour certains fournisseurs. **Ne pas supposer que chaque visuel IA nécessite exactement le même bandeau** : analyser la nature du contenu, l'acteur (fournisseur/déployeur), les exceptions et les règles locales/plateforme. Une disclosure volontaire claire peut être prudente sans se présenter comme une conclusion juridique universelle.

Minimiser les données de casting et prospects. Pour RGPD : traiter exclusivement les données professionnelles nécessaires, documenter objectif/accès/conservation, éviter le profiling sensible et les captures massives. La CNIL publie des principes utiles sur les données de candidats : https://www.cnil.fr/fr/le-guide-du-recrutement ; pour des prestations de créateurs, appliquer le cadre correspondant plutôt que supposer automatiquement le régime juridique d'embauche.

## 4. TikTok — création et amplification

- Guide vidéo officiel : https://ads.tiktok.com/business/en/guides/video-advertising-guide
- Creative best practices : https://ads.tiktok.com/business/fr/blog/creative-best-practices-top-performing-ads
- TikTok One / découverte : https://ads.tiktok.com/resources/help/article/how-to-find-creators-who-work-with-tiktok-one?lang=fr
- Format et fonctionnement (policies) : https://ads.tiktok.com/help/article/tiktok-ads-policy-ad-format-and-functionality?lang=fr
- Commercial Music Library : https://ads.tiktok.com/help/article/commercial-music-library?lang=fr
- Spark Ads et autorisation : https://ads.tiktok.com/resources/help/article/spark-ads?lang=fr

Concevoir d'abord pour écran vertical plein, recommandé 9:16, master 1080×1920 ; garder texte et CTA hors des zones masquées dans **l'aperçu de placement réel**. Montrer une situation immédiatement, avec preuve et CTA. Le contenu publicitaire TikTok a besoin d'une bande-son adaptée, ce qui n'empêche pas la lisibilité des incrustations sans son. Pour une publicité, ne pas reprendre un morceau de la bibliothèque musicale générale : vérifier licence commerciale (CML ou droits propres). Une publication UGC organique d'un tiers **n'accorde pas** l'autorisation Spark Ads : elle doit être obtenue pour le compte, la vidéo, le territoire et la période concernés.

## 5. Instagram/Facebook Reels / Meta

Toujours ouvrir le **Meta Ads Guide/preview actif** avant d'affirmer la taille des safe zones, la durée autorisée ou les options Partnership Ads : les placements et contraintes changent. Concevoir un master vertical 9:16, sous-titré, avec preuve produit et CTA, puis contrôler le rendu avec le décor et les superpositions d'interface de chaque placement. Contrôler les droits publicitaires du contenu de créateur, les options de partenariat rémunéré et de réutilisation sans confondre compte public et accord d'utilisation. Ne pas donner de marge « 250 px » comme universellement sûre sans test d'aperçu.

## 6. YouTube Shorts / Google Ads

- Guide officiel : https://support.google.com/google-ads/answer/16041697?hl=fr

Google recommande des annonces Shorts verticales 9:16, natives/social-first, avec son, de préférence brèves pour le flux Shorts et cohérentes avec objectif/CTA. Le comportement et les restrictions de durée dépendent du produit publicitaire ; vérifier au moment du dépôt. Ne pas confondre durée d'un Shorts organique et portion diffusée dans le flux publicitaire. Tester les superpositions CTA, titre, description et adéquation aux campagnes vidéo utilisées.

## 7. États-Unis (si ciblage US)

- FTC Endorsement Guides : https://www.ftc.gov/business-guidance/resources/ftcs-endorsement-guides-what-people-are-asking

Un lien matériel à la marque peut exiger une divulgation claire et visible ; un outil de plateforme ne remplace pas forcément cette obligation. Les témoignages et endorsements ne doivent pas induire en erreur. Réévaluer l'applicabilité pour la juridiction et la campagne concernées.

## 8. Checklist des droits avant publication

- [ ] Talents/voix/figurations : consentements vérifiables, mineurs examinés si concernés.
- [ ] Créateurs : licence d'utilisation détaillée (organic/paid, durée, territoire, plateformes, montage, modifications, exclusivité si négociée).
- [ ] Publication depuis compte créateur : autorisation publicitaire distincte, si technique l'exige.
- [ ] Musique, effets, photographie, B-roll, typographies, décors et marques tierces : droits adaptés à publicité payante.
- [ ] Produit disponible et page de destination conforme au message.
- [ ] Prix et conditions de précommande, frais et délais transparents si mentionnés.
- [ ] Claims documentés et archives des preuves ; expertise spécifique si allégations santé/écologiques/financières.
- [ ] Identification de la publicité ou partenariat et de l'usage pertinent de l'IA.
- [ ] Vérification humaine et validation finale consignées.

**Aucune ligne ci-dessus ne peut être marquée `VERIFIED` par simple supposition du modèle.**
