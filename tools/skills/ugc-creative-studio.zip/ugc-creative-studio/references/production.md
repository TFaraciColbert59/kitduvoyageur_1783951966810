# Département PRODUCTION — P1 à P5

**Objectif :** transformer la stratégie en publicité tournable et montable. Ne pas reproduire les slogans, images, sons, visages ou styles distinctifs d'une campagne protégée. Optimiser pour **clarté, émotion, crédibilité, rythme et action** ; la performance réelle se mesure après diffusion.

## P1 — Concept & Angle Lab / concepteur-rédacteur + directeur artistique

Produire **3 concepts visiblement distincts** avec, pour chacun :

1. `Tension humaine` : le désir, la gêne ou le problème en situation concrète ; ne pas culpabiliser ni stigmatiser.
2. `Démo convaincante` : avant/après *véridique*, mini test, mise en pratique ou comparaison licite.
3. `Révélation contre-intuitive` : une idée qui rompt la routine de la cible sans appât mensonger.

Pour chaque concept, donner : titre, public, déclencheur, « vérité humaine », promesse vérifiable, preuve à filmer, trajectoire émotionnelle, première image, hook verbal, dispositif d'incarnation, contraintes, difficulté de tournage, CTA, risques. Ajouter un concept de **marque / aspiration** si lancement ou Kickstarter, à distinguer des objectifs de conversion directe.

Évaluer (0–5) : singularité pertinente, visualisabilité, crédibilité, lien CTA, adéquation à la plateforme. Ne pas privilégier une simple beauté esthétique si le message est opaque.

## P2 — Hook Lab / spécialiste 0–3 s

Pour chaque concept produire au moins 3 accroches, en couvrant au total ces **familles indépendantes** :

- **Visuel** : résultat ou situation intrigante déjà visible à l'image zéro.
- **Tension** : « J'avais prévu X. Le problème, c'était Y. » (si expérience réelle).
- **Démonstration** : commencer par l'action, pas le logo.
- **Contraste** : comparaison visuelle prouvable, pas une performance inventée.
- **Objection** : réponse à « encore une appli / gadget ? ».
- **Identification** : nommer une situation précise où l'utilisateur se reconnaît.
- **Curiosité honnête** : différer une révélation sans promettre l'impossible.
- **Aspiration** : projection dans un résultat humain souhaitable.

Garder un document `HOOK BANK` avec `ID`, phrase parlée exacte, première image, texte affiché, émotion, preuve attendue, objection ciblée, dépendance éventuelle, score de lisibilité et risque de faux espoir. Sélectionner 3–5 hooks vraiment différents (pas trois synonymes). Faire lire à haute voix : la première phrase doit sonner naturelle.

**Test du défilement :** image initiale intelligible sans son, signe d'un changement dans les 1–2 premières secondes, valeur comprise rapidement, pas d'intro générique ni de clickbait trompeur. Ceci est une heuristique, pas une garantie algorithmique.

## P3 — Scriptwriting Room / script doctor

**Règle de calcul :** estimer `temps_parole = nombre_de_mots / débit_mots_par_seconde`. Valeur de travail initiale **2,3 à 2,7 mots/s** (138–162 mots/min), variable selon comédien et langue. Ajouter respirations, démos silencieuses, pauses et transitions ; confirmer le runtime en répétition enregistrée, plutôt que promettre une durée exacte depuis le texte.

**Structure recommandée** (à adapter au récit, pas un carcan) :

1. 0–3 s : image/hook compréhensible, sans titre d'ouverture.
2. 3–8 s : situation, friction ou désir spécifique.
3. 8–20 s : produit en situation, preuve visuelle, démonstration ou mécanisme.
4. 20–fin : bénéfice traduit en usage quotidien et CTA honnête.

**Le script doit être jouable :**

| TC début-fin | Dialogue exact | Action/cadre | Texte écran | Preuve/réserve | Audio |
|---|---|---|---|---|---|
| 00:00–00:02 | « … » | Gros plan sur une situation | 3–5 mots | Claim-ID ou aucune | Ambiance réelle |

**Variantes :**

- 15 secondes : une seule proposition et une preuve ; idéal pour découverte rapide, pas pour un argumentaire complet.
- 30 secondes : problème, démo, objection et CTA ; version pivot.
- 60 secondes : séquence narrative plus posée, plusieurs preuves vérifiées, version de marque ou pédagogie approfondie ; le format doit être compatible avec la plateforme/campagne.
- Version **UGC authentique** : gestes, hésitations légères naturelles, phrases parlées, micro-anecdote réellement vécue ; pas de faux témoignage à la première personne.
- Version **studio/voix-off/IA** : ton honnêtement démonstratif et non présenté comme un utilisateur réel ; les voix et personnages nécessitent les droits et mentions adaptés.
- Version **lancement non finalisé** : « conçu pour », « nous développons », « préinscriptions ouvertes » uniquement si vérifié, jamais « déjà disponible » ou « livré » sans preuve.

Pour chaque script, fournir : nombre de mots parlés, durée estimée, vitesse requise, variations possibles de ton, visuels indispensables, élément de réassurance, dernière image et une proposition de sous-titrage.

## P4 — Storyboard & Shotlist / réalisateur + chef opérateur

Pour chaque plan renseigner :

- numéro et TC in/out, durée approximative, action réellement réalisable, cadre/axe, mouvement, décor, lumière, produit/écran visible, source média ;
- dialogue/VO, son direct, musique ou silence, sous-titre et placement, raccord plan précédent/suivant ;
- rôle du plan (hook, preuve, respiration, objection, CTA) ;
- contraintes et doublure/plan B quand mouvement, lieu, météo, interface ou acteur indisponible ;
- licence et autorisation nécessaires (lieu privé, figurant, signe distinctif, audio, B-roll sous licence).

**Exiger :** plan d'ouverture fort, plan produit en usage, variation visuelle motivée et fin sans désorientation. **Éviter :** suite de plans génériques de banque d'images ne prouvant pas la proposition. Pour une vidéo d'interface, indiquer la capture d'écran à produire, la résolution, l'état exact et une vérification de cohérence avec le produit courant.

**Storyboard textuel obligatoire** si génération d'image non disponible. Une image générée, si un outil la produit, reste un aperçu créatif et ne prouve pas la faisabilité physique de l'action.

## P5 — Production Kit & Postproduction / producer exécutif + monteur

### Kit de production

- **Talent** : rôle, mode de captation, autorisation, garde-robe sans marque tierce problématique, directives de jeu, prononciation du produit, contenu sensible interdit.
- **Tournage** : vertical 9:16 par défaut pour short-form, captation nette, focus et exposition, prise micro, 3 secondes de room tone, espace pour incrustations ; adaptation par canal.
- **Prises** : 2 versions d'intention par phrase, 2 hooks contrastés, 1 plan de secours sans talent, B-roll, détail fonctionnel, CTA à distance suffisante pour lecture.
- **Fichiers** : rushes nommés `CAMPAIGN_CONCEPT_SHOT_TAKE.ext`, script final versionné, consentements séparés, montage avec stems audio et fichiers sous-titres.
- **Montage** : rythme justifié, premières images sans logo d'attente, sous-titres relus, textures sonores licenciées, pas de jump cuts masquant des conditions du produit, aucun faux avant/après.
- **Exports** : master sans watermark, version sous-titrée, version clean, fichiers sources si négociés, 9:16 (1080×1920 comme cible pratique), déclinaisons 4:5 et 16:9 sur besoin ; valider techniquement selon placement courant.
- **Budget** : séparer création/acteur/logistique/musique/montage/droits paid media/retakes. Coûts en fourchettes **hypothétiques** sans devis ; ne pas dépenser automatiquement.

### Production IA assistée : compatible sans dépendance imposée

Utiliser des outils effectivement installés/explicitement autorisés pour **générer** et **monter** des plans. Sans ces outils, produire un `GENERATION_PACKAGE` contenant pour chaque plan : intention, action détaillée, cadrage, décor, continuité personnages/objets, source de référence détenue légalement, prompt image/vidéo, prompt audio, **negative constraints**, durée, méthode de raccord, validation humaine attendue. Ne pas promettre une vidéo finale sans fichier export contrôlé.

**Garde-fous IA :** éviter faux témoignages, clones non autorisés, substitution d'un vrai créateur, métadonnées trompeuses et produit physiquement impossible. Déclarer la synthèse lorsque requis. Protéger tout secret de fabrication et tout asset confidentiel.

### Vérification préalable à transfert montage

1. La bande-son a une licence pour l'usage **payant** et les territoires visés.
2. Chaque source (rushes, musique, graphisme, modèle, voix) est identifiée et documentée.
3. Les textes à l'écran passent le test de lecture sur téléphone et ne sont pas masqués par l'interface du placement.
4. Les sous-titres restituent fidèlement le discours, et l'action principale reste compréhensible sans le son quand cela s'applique.
5. La version diffusée correspond bien à la version approuvée ; conservation des versions et changements.
6. Le lien final de la pub mène à une page cohérente et fonctionnelle ; ne pas décrire un test de clic comme effectué s'il ne l'a pas été.

## Livrable production : critères de réception

**Il est insuffisant de fournir une « idée de publicité ».** La production inclut l'accroche mot pour mot, la vidéo mentale image par image, la phrase à dire, le geste précis, la source des visuels, le sous-titre et le montage attendu, avec les dépendances clairement listées. Toute impossibilité de tournage donne un plan de remplacement.


## P4/P5 — Pipeline de création MP4 (extension intégrée, pas un skill supplémentaire)

Quand le demandeur veut la **vidéo elle-même** : lire `references/rendering-pipeline.md` et `references/visual-style-library.md`. Distinguer trois réalités : `code_video` (animation dessinée par code, MP4 local), `real_ugc` (rushes filmés autorisés), `hybrid` (rushes + overlays/effets codés). Ne pas faire passer du motion design pour une expérience utilisateur réelle.

Pour `code_video`, livrer `creative-spec.md`, `timeline.json`, `scene.html` autonome avec `window.renderAt(t)`, audio original ou autorisé, puis exécuter le rendu local `scripts/render_video.mjs` si les outils sont disponibles. La géométrie et les textes sont redessinés à chaque timecode t, indépendants de l'horloge et des frames antérieures. Les textes doivent rester nets en 9:16, et le CTA rester lisible à la taille de téléphone.

Réviser d'abord les captures aux points 0/25/50/75/99 % et aux transitions, puis inspecter la vidéo complète avec `scripts/inspect_video.py`, écouter l'audio et documenter les écarts. Si l'outil est absent, conserver tous les livrables mais statut `BLOCKED_RENDER`, jamais `MP4 produit`.
