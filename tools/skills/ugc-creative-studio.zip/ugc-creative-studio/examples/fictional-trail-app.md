# Démonstration fictive — LumaPath (marque inventée)

> **EXEMPLE D'ÉVALUATION, PAS UNE VRAIE CAMPAGNE NI UN PRODUIT VÉRIFIÉ.** LumaPath est une application de planification de sorties imaginée uniquement pour montrer les livrables. Aucune fonctionnalité, avis, performance ou prix ci-dessous n'est réel.

## Brief

- Offre fictive : application proposant de construire manuellement une checklist avant une promenade.
- Objectif : recueillir l'intérêt pour une page d'attente ; CTA : « Rejoins la liste d'attente ».
- Cible comportementale : personnes qui partent en balade et oublient parfois de petits éléments utiles.
- Promesse sûre : « Une idée pour préparer ta sortie dans la même interface » ; formulation de concept, non de produit commercialisé.
- À éviter : « téléchargement disponible », « n'oublie plus jamais rien », « approuvé par 10 000 randonneurs », « 100 % gratuit » et tout avis attribué à un vrai client.
- Casting : acteur UGC théorique, non sourcé ; ne pas jouer un témoignage « j'utilise l'appli depuis des mois ».

## Trois territoires

A. **Émotion** : « Le plus beau de la sortie, c'est de pouvoir décrocher. » La préparation est représentée par un geste simple, sans promettre un résultat réel.

B. **Démo** : un petit objet oublié dans la voiture ; la personne ouvre une **maquette identifiée comme telle** d'une future checklist.

C. **Renversement** : « La promenade ne commence pas au départ du sentier. » Le récit débute à la veille du départ.

## Hook bank fictif

| ID | Hook verbal | Première image | Risque |
|---|---|---|---|
| HK-01 | « La meilleure partie de ma sortie ? Quand tout est déjà prêt. » | Sac fermé près de la porte | Ne pas impliquer qu'une app existe déjà |
| HK-02 | « Ce n'est pas la distance qui gâche une balade. » | Gourde oubliée sur une table | Éviter une généralisation absolue |
| HK-03 | « Et si la préparation était aussi simple que le départ ? » | Maquette visuellement étiquetée | Montrer « prototype » clairement |

## Script démonstratif ~30 secondes (fictif)

| TC | Dialogue | Image | Texte |
|---|---|---|---|
| 00:00–00:03 | « Le départ de la balade commence souvent la veille. » | Petit sac ouvert, gourde sur table | AVANT DE PARTIR |
| 00:03–00:07 | « Entre les clés, l'eau et la météo, on pense à tout… enfin presque. » | Main qui cherche un objet ; petit sourire | LES PETITS OUBLIS |
| 00:07–00:13 | « Alors on imagine LumaPath : une checklist claire pour préparer chaque sortie. » | Écran maquette avec label PROTOTYPE | UN PROJET EN COURS |
| 00:13–00:21 | « L'idée : choisir ce qu'on emmène, vérifier ce qui manque, et partir l'esprit plus léger. » | Prototype démontrant une liste fictive ; personne ferme le sac | CONCEPT DE CHECKLIST |
| 00:21–00:28 | « Ça te parle ? Rejoins la liste d'attente et suis la création du projet. » | Affichage d'une landing page fictive à remplacer | REJOINDRE LA LISTE |
| 00:28–00:30 | Pas de dialogue ; musique douce sous licence à définir | Retour au sac et au nom de la marque | LUMAPATH — CONCEPT |

**Runtime à mesurer réellement** avec la voix ; la table est un plan de tournage, pas une vidéo existante. Le prototype n'existe pas et doit être créé ou remplacé avant toute production. Aucune page de liste d'attente n'a été vérifiée.

## QA fictive

- Score éditorial heuristique d'illustration : non noté en l'absence de réalisation.
- Gate B : stratégie illustrée, **fiches produit et preuves inexistantes**.
- Gate C : casting théorique uniquement, pas de créateur contacté.
- Gate P : script préparatoire, storyboard et sous-titres à consolider ; aucune vidéo produite.
- Gate Q : `NO-GO DIFFUSION` ; droits de voix/musique/vidéo non obtenus, landing page fictive, vérification de promesse et politique non effectuée.

**Exemple de bonne sortie :** « Dossier de concept prêt à évaluer ; impossible de diffuser sans véritable offre, assets, consentements et revue finale ». 
