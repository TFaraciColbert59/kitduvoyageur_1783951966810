#!/usr/bin/env python3
"""Independent ffprobe technical gate. Does NOT clear claims or rights."""
import argparse
import json
import math
import subprocess
import sys
from pathlib import Path


def probe_video(file: Path, width: int, height: int, fps: float, duration: float, require_audio: bool = False) -> dict:
    if not file.is_file() or file.stat().st_size == 0:
        raise ValueError('MP4 absent ou vide')
    cmd = ['ffprobe', '-v', 'error', '-show_format', '-show_streams', '-of', 'json', str(file)]
    run = subprocess.run(cmd, capture_output=True, text=True, timeout=20, check=True)
    parsed = json.loads(run.stdout)
    streams = parsed.get('streams', [])
    video = next((s for s in streams if s.get('codec_type') == 'video'), None)
    audios = [s for s in streams if s.get('codec_type') == 'audio']
    if not video:
        raise ValueError('Piste vidéo absente')
    issues = []
    if video.get('codec_name') != 'h264': issues.append('Codec différent de H.264')
    if int(video.get('width', 0)) != width or int(video.get('height', 0)) != height: issues.append('Dimensions incorrectes')
    actual_dur = float(video.get('duration') or parsed.get('format', {}).get('duration') or 0)
    if abs(actual_dur - duration) > max(0.12, 1 / max(fps, 1)): issues.append('Durée incorrecte')
    n, d = (video.get('avg_frame_rate') or '0/1').split('/')
    actual_fps = float(n)/float(d)
    if abs(actual_fps - fps) > 0.01: issues.append('FPS incorrect')
    if require_audio and not audios: issues.append('Audio absent')
    if video.get('pix_fmt') != 'yuv420p': issues.append('Pixel format attendu yuv420p')
    return {'status': 'PASS_TECHNIQUE' if not issues else 'FAIL_TECHNIQUE',
            'video_codec': video.get('codec_name'), 'width': video.get('width'), 'height': video.get('height'),
            'fps': actual_fps, 'duration': actual_dur, 'audio_present': bool(audios),
            'size_bytes': file.stat().st_size, 'issues': issues,
            'note': 'N atteste ni visuels, ni véracité publicitaire, ni droits, ni conformité.'}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('video', type=Path)
    parser.add_argument('--width', type=int, required=True)
    parser.add_argument('--height', type=int, required=True)
    parser.add_argument('--fps', type=float, required=True)
    parser.add_argument('--duration', type=float, required=True)
    parser.add_argument('--require-audio', action='store_true')
    parser.add_argument('--json', action='store_true')
    args = parser.parse_args()
    try:
        result = probe_video(args.video, args.width, args.height, args.fps, args.duration, args.require_audio)
        print(json.dumps(result, ensure_ascii=False, indent=2) if args.json else f"{result['status']}: {result}")
        return 0 if not result['issues'] else 1
    except (ValueError, OSError, subprocess.SubprocessError, json.JSONDecodeError) as e:
        print(f'FAIL_TECHNIQUE: {e}', file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
