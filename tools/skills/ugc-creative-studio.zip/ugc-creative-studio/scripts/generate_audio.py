#!/usr/bin/env python3
"""Original, deterministic, license-free procedural cue (not a copy of a song)."""
import argparse
import math
import random
import struct
import wave
from pathlib import Path


def render_wav(destination: Path, seconds: float, seed: int = 1, bpm: int = 100) -> None:
    if not 0.1 <= seconds <= 600:
        raise ValueError('seconds must be in [0.1, 600]')
    if not 45 <= bpm <= 200:
        raise ValueError('bpm must be in [45, 200]')
    rng = random.Random(seed)
    sample_rate = 22050
    beat = 60 / bpm
    # Original two-bar progression. Not based on an existing melody.
    progression = [(174.61, 220.00, 261.63), (146.83, 196.0, 246.94),
                   (164.81, 220.0, 261.63), (130.81, 174.61, 220.0)]
    destination.parent.mkdir(parents=True, exist_ok=True)
    with wave.open(str(destination), 'wb') as wav:
        wav.setnchannels(1)
        wav.setsampwidth(2)
        wav.setframerate(sample_rate)
        buf = bytearray()
        for i in range(round(seconds * sample_rate)):
            t = i / sample_rate
            chord = progression[int(t / (beat * 4)) % len(progression)]
            # Slow swell, simple additive synth, low mixed level and fade in/out.
            swell = 0.36 + 0.16 * math.sin(t * 0.6)
            pad = sum(math.sin(math.tau * hz * t) for hz in chord) / len(chord)
            pad += 0.13 * math.sin(math.tau * chord[0] * 0.5 * t)
            local = (t % beat) / beat
            click = 0.07 * (1 - local / 0.18) * math.sin(math.tau * 660 * t) if local < 0.18 else 0
            quiet = 0.0008 * rng.uniform(-1, 1)
            fade = min(1, t / 0.12, max(0, (seconds - t) / 0.20))
            sample = max(-0.85, min(0.85, (0.20 * swell * pad + click + quiet) * fade))
            buf += struct.pack('<h', int(sample * 32767))
            if len(buf) >= 32768:
                wav.writeframesraw(buf)
                buf.clear()
        if buf:
            wav.writeframesraw(buf)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--seconds', type=float, required=True)
    parser.add_argument('--seed', type=int, default=1)
    parser.add_argument('--bpm', type=int, default=100)
    args = parser.parse_args()
    render_wav(args.output, args.seconds, args.seed, args.bpm)
    print(f'Original WAV generated: {args.output}')


if __name__ == '__main__':
    main()
