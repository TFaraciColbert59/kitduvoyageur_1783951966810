#!/usr/bin/env python3
"""Vérifie la structure d'un dossier UGC, sans certifier ses faits ni ses droits.

Usage : python3 verify_campaign.py campaigns/mon-campagne --goal preproduction|publish
Aucune connexion réseau, aucun package externe, aucune mutation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

REQUIRED_ARTIFACTS = {
    "brief": "01_BRIEF.md",
    "casting": "02_CASTING.md",
    "concepts": "03_CONCEPTS.md",
    "scripts": "04_SCRIPTS.md",
    "storyboard": "05_STORYBOARD.md",
    "qa": "06_QA.md",
    "test_plan": "07_TEST_PLAN.md",
}

REQUIRED_CLEARANCES = (
    "talent_release",
    "usage_rights",
    "media_rights",
    "music_rights",
    "ad_disclosure",
    "ai_transparency",
    "platform_policy",
    "brand_approval",
    "final_visual_check",
    "landing_page_check",
)

VALID_STATUSES = {"verified", "pending", "rejected", "not_applicable"}
VALID_PRODUCTION = {"real_ugc", "brand_owned", "synthetic", "hybrid"}
VIDEO_SUFFIXES = {".mp4", ".mov", ".webm", ".m4v"}


def is_text(value: Any, min_length: int = 1) -> bool:
    return isinstance(value, str) and len(value.strip()) >= min_length


def safe_file(root: Path, value: Any) -> Path | None:
    """Rejects absolute paths, traversal, and escaping symlinks."""
    if not is_text(value):
        return None
    relative = Path(value)
    if relative.is_absolute() or ".." in relative.parts:
        return None
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root.resolve())
    except ValueError:
        return None
    return candidate


def validate_campaign(root: Path, goal: str = "preproduction") -> tuple[list[str], list[str]]:
    """Returns (errors, warnings). Zero errors means *structure* passes only."""
    errors: list[str] = []
    warnings: list[str] = []

    if goal not in {"preproduction", "publish"}:
        return ["Objectif invalide : choisir preproduction ou publish."], warnings

    manifest_path = root / "manifest.json"
    if not manifest_path.is_file():
        return ["manifest.json absent."], warnings
    try:
        data = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
        return [f"manifest.json illisible ou JSON invalide : {exc}"], warnings
    if not isinstance(data, dict):
        return ["Le manifeste doit être un objet JSON."], warnings

    if data.get("schema_version") != 1:
        errors.append("schema_version doit être 1.")
    if not is_text(data.get("campaign_id")):
        errors.append("campaign_id manquant.")
    if not isinstance(data.get("market"), list) or not data["market"] or not all(
        is_text(item) for item in data["market"]
    ):
        errors.append("market doit contenir au moins un marché explicite.")
    if not is_text(data.get("objective")):
        errors.append("objective absent.")
    if data.get("production_method") not in VALID_PRODUCTION:
        errors.append("production_method doit valoir real_ugc, brand_owned, synthetic ou hybrid.")
    score = data.get("creative_score")
    if score is not None and (type(score) not in {int, float} or not 0 <= score <= 100):
        errors.append("creative_score doit être null ou un nombre entre 0 et 100.")
    if score is None:
        warnings.append("Score éditorial non renseigné (aucune performance n'est inférée).")

    artifacts = data.get("artifacts")
    if not isinstance(artifacts, dict):
        errors.append("artifacts doit être un objet contenant les sept livrables.")
    else:
        for key in REQUIRED_ARTIFACTS:
            file_path = safe_file(root, artifacts.get(key))
            if file_path is None or not file_path.is_file():
                errors.append(f"Artefact {key} absent, non sûr ou non accessible : {artifacts.get(key)!r}.")
            elif file_path.suffix.lower() != ".md":
                errors.append(f"Artefact {key} doit être en Markdown.")
            else:
                try:
                    content = file_path.read_text(encoding="utf-8")
                    if not content.lstrip().startswith("# ") or len(content.strip()) < 80:
                        errors.append(f"Artefact {key} vide ou insuffisamment documenté.")
                except (OSError, UnicodeDecodeError):
                    errors.append(f"Artefact {key} illisible en UTF-8.")

    claims = data.get("claims")
    if not isinstance(claims, list):
        errors.append("claims doit être une liste (éventuellement vide avec justification).")
    else:
        if not claims and not is_text(data.get("claim_free_reason"), 10):
            errors.append("Justifier l'absence de claims via claim_free_reason.")
        ids: set[str] = set()
        for index, claim in enumerate(claims, 1):
            label = f"Claim #{index}"
            if not isinstance(claim, dict):
                errors.append(f"{label} doit être un objet.")
                continue
            claim_id = claim.get("id")
            if not is_text(claim_id):
                errors.append(f"{label} n'a pas d'id.")
            elif claim_id in ids:
                errors.append(f"{label} a un id dupliqué : {claim_id}.")
            else:
                ids.add(claim_id)
            if not is_text(claim.get("text")):
                errors.append(f"{label} sans texte.")
            status = claim.get("status")
            if status not in VALID_STATUSES:
                errors.append(f"{label} a un statut invalide.")
            if type(claim.get("used_in_scripts")) is not bool:
                errors.append(f"{label} doit déclarer used_in_scripts true/false.")
            elif claim["used_in_scripts"] and status != "verified":
                errors.append(f"{label} figure dans le script sans vérification probante.")
            if status == "verified" and not (
                is_text(claim.get("evidence"), 8) and is_text(claim.get("source_ref"), 5)
            ):
                errors.append(f"{label} vérifié sans référence ni explication de preuve suffisante.")
            if status in {"pending", "rejected"}:
                warnings.append(f"{label} est {status} et ne doit pas servir de promesse publicitaire.")

    clearances = data.get("clearances")
    if not isinstance(clearances, dict):
        errors.append("clearances doit contenir les contrôles de droits et de diffusion.")
    else:
        for key in REQUIRED_CLEARANCES:
            item = clearances.get(key)
            if not isinstance(item, dict):
                errors.append(f"Contrôle {key} manquant.")
                continue
            status = item.get("status")
            evidence = item.get("evidence")
            if status not in VALID_STATUSES:
                errors.append(f"Contrôle {key} : statut invalide.")
                continue
            if not is_text(evidence, 8):
                errors.append(f"Contrôle {key} : justifier la preuve ou la non-applicabilité.")
            if goal == "publish" and status not in {"verified", "not_applicable"}:
                errors.append(f"Publication bloquée : {key} = {status}.")
            elif goal == "preproduction" and status in {"pending", "rejected"}:
                warnings.append(f"Contrôle à lever avant diffusion : {key} = {status}.")

    video_name = data.get("final_video")
    if goal == "publish":
        video = safe_file(root, video_name)
        if video is None or not video.is_file() or video.suffix.lower() not in VIDEO_SUFFIXES:
            errors.append("Publication bloquée : fichier final_video local non trouvé ou format inattendu.")
        elif video.stat().st_size == 0:
            errors.append("Publication bloquée : final_video est vide.")
        else:
            warnings.append("Le fichier vidéo existe ; sa lecture, son contenu, sa qualité et ses droits restent à contrôler par un humain.")
    elif video_name is None:
        warnings.append("Aucune vidéo finale : c'est un dossier de préparation, pas une publicité livrée.")

    return errors, warnings


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("campaign_dir", type=Path, help="Dossier contenant manifest.json")
    parser.add_argument("--goal", choices=("preproduction", "publish"), default="preproduction")
    args = parser.parse_args()
    errors, warnings = validate_campaign(args.campaign_dir, args.goal)
    for warning in warnings:
        print(f"AVERTISSEMENT : {warning}")
    for error in errors:
        print(f"BLOQUANT : {error}")
    if errors:
        print(f"ÉCHEC STRUCTUREL : {len(errors)} blocage(s). Aucune publication autorisée.")
        return 1
    print("STRUCTURE VALIDÉE — ne certifie ni vérité, ni conformité, ni publication.")
    if args.goal == "publish":
        print("CONTRÔLE HUMAIN FINAL, DROITS, VÉRACITÉ ET PLACEMENT TOUJOURS OBLIGATOIRES.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
