#!/usr/bin/env node
/** Standalone Chrome DevTools Protocol + FFmpeg renderer. No npm packages. Node 22+.
 * Calls a deterministic window.renderAt(seconds) and encodes PNG screenshots
 * directly into FFmpeg stdin, so full-size frame files need not be written.
 */
import { spawn, spawnSync } from 'node:child_process';
import { once } from 'node:events';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { setTimeout as pause } from 'node:timers/promises';

const HELP = `Usage: node render_video.mjs <scene.html> --output <video.mp4> [options]

Options:
  --width 1080      Frames width, in pixels (even integer)
  --height 1920     Frames height, in pixels (even integer)
  --fps 30          Frames per second, 1..60
  --duration 15     Duration in seconds (0.1..600)
  --audio PATH      Optional original or licensed WAV/MP3 track
  --chrome PATH     Chrome/Chromium executable; autodetected otherwise
  --stills DIR      Save sample frames at 0,25,50,75,99% for human visual QA
  --overwrite       Replace existing output (never default)
  --help            Show this help

Scene contract: A self-contained HTML page declaring async/sync window.renderAt(t).
The function must draw the complete frame for exactly t seconds, not rely on
performance.now(), wall time, animation timers or external services.
Uses headless Chrome CDP and FFmpeg; all rendering remains local.
`;

function parseArgs(argv) {
  if (argv.includes('--help') || argv.includes('-h')) return { help: true };
  const out = { width: 1080, height: 1920, fps: 30, duration: 15, overwrite: false };
  const positional = [];
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--overwrite') out.overwrite = true;
    else if (['--width', '--height', '--fps', '--duration', '--audio', '--chrome', '--output', '--stills'].includes(a)) {
      if (i + 1 >= argv.length) throw new Error(`Missing value for ${a}`);
      out[a.slice(2)] = argv[++i];
    } else if (a.startsWith('--')) throw new Error(`Unknown option ${a}`);
    else positional.push(a);
  }
  if (positional.length !== 1) throw new Error('One input scene.html is required. See --help.');
  out.scene = path.resolve(positional[0]);
  if (!out.output) throw new Error('Missing --output <video.mp4>.');
  out.output = path.resolve(out.output);
  for (const key of ['width', 'height', 'fps', 'duration']) {
    if (out[key] === '' || out[key] === null) throw new Error(`Invalid ${key}`);
    out[key] = Number(out[key]);
    if (!Number.isFinite(out[key])) throw new Error(`Invalid ${key}`);
  }
  for (const key of ['width', 'height']) {
    if (!Number.isInteger(out[key]) || out[key] < 2 || out[key] % 2) throw new Error(`${key} must be a positive even integer`);
  }
  if (out.width * out.height > 3840 * 2160) throw new Error('Maximum frame size: 8,294,400 pixels (4K).');
  if (!Number.isInteger(out.fps) || out.fps < 1 || out.fps > 60) throw new Error('fps must be an integer between 1 and 60');
  if (out.duration < 0.1 || out.duration > 600) throw new Error('duration must be between 0.1 and 600 seconds');
  if (!fs.existsSync(out.scene) || path.extname(out.scene).toLowerCase() !== '.html') throw new Error('Input scene.html not found');
  if (!fs.statSync(out.scene).isFile()) throw new Error('Input scene is not a file');
  if (fs.existsSync(out.output) && !out.overwrite) throw new Error('Output exists; pass --overwrite to replace it');
  if (out.audio && !fs.existsSync(path.resolve(out.audio))) throw new Error('Audio track not found');
  if (path.extname(out.output).toLowerCase() !== '.mp4') throw new Error('Output must have .mp4 extension');
  return out;
}

function findChrome(custom) {
  const choices = [custom, process.env.CHROME_BIN,
    '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
    '/Applications/Chromium.app/Contents/MacOS/Chromium',
    '/usr/bin/google-chrome', '/usr/bin/chromium', 'google-chrome', 'chromium'];
  for (const candidate of choices.filter(Boolean)) {
    if (candidate.includes('/') && fs.existsSync(candidate)) return candidate;
    if (!candidate.includes('/')) {
      const c = spawnSync(process.platform === 'win32' ? 'where' : 'which', [candidate], {encoding: 'utf8'});
      if (c.status === 0) return c.stdout.trim().split(/\r?\n/)[0];
    }
  }
  throw new Error('Chrome/Chromium not found: specify --chrome');
}

class CDP {
  constructor(url) { this.ws = new WebSocket(url); this.pending = new Map(); this.nextId = 0; }
  async connect() {
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('CDP websocket timeout')), 10000);
      this.ws.addEventListener('open', () => { clearTimeout(timeout); resolve(); }, { once: true });
      this.ws.addEventListener('error', (e) => { clearTimeout(timeout); reject(new Error(`CDP socket: ${e.message || 'error'}`)); }, { once: true });
    });
    this.ws.addEventListener('message', ({ data }) => {
      const msg = JSON.parse(data);
      if (msg.id && this.pending.has(msg.id)) {
        const p = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        clearTimeout(p.timer);
        msg.error ? p.reject(new Error(`${p.method}: ${msg.error.message}`)) : p.resolve(msg.result || {});
      } else if (msg.method === 'Runtime.exceptionThrown') {
        const d = msg.params?.exceptionDetails;
        process.stderr.write(`Chrome exception: ${d?.text || d?.exception?.description || 'unknown'}\n`);
      } else if (msg.method === 'Runtime.consoleAPICalled' && msg.params?.type === 'error') {
        process.stderr.write(`Browser console error: ${(msg.params.args || []).map(x => x.value || x.description || '').join(' ')}\n`);
      }
    });
  }
  send(method, params = {}) {
    return new Promise((resolve, reject) => {
      const id = ++this.nextId;
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`CDP timeout: ${method}`));
      }, 30000);
      this.pending.set(id, { resolve, reject, timer, method });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expression) {
    const value = await this.send('Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: false });
    if (value.exceptionDetails) throw new Error(`Scene JS: ${value.exceptionDetails.exception?.description || value.exceptionDetails.text}`);
    return value.result?.value;
  }
  close() { try { this.ws.close(); } catch {} }
}

async function waitForChrome(dir, chrome, timeoutMs = 18000) {
  const active = path.join(dir, 'DevToolsActivePort');
  const stop = Date.now() + timeoutMs;
  while (Date.now() < stop) {
    if (chrome.exitCode !== null) throw new Error(`Chrome exited early with code ${chrome.exitCode}`);
    if (fs.existsSync(active)) return Number(fs.readFileSync(active, 'utf8').split('\n')[0]);
    await pause(100);
  }
  throw new Error('Chrome did not open remote debugging port');
}

async function run(opts) {
  if (!globalThis.WebSocket) throw new Error('Use Node.js 22 or newer for native WebSocket');
  const chromePath = findChrome(opts.chrome);
  const ff = spawnSync('ffmpeg', ['-version'], { encoding: 'utf8' });
  if (ff.status !== 0) throw new Error('FFmpeg is required on PATH');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'ugc-render-'));
  let chrome;
  let cdp;
  let encoder;
  let succeeded = false;
  const targetDir = path.dirname(opts.output);
  fs.mkdirSync(targetDir, { recursive: true });
  const frames = Math.round(opts.duration * opts.fps);
  if (frames < 1) throw new Error('At least one frame is required');
  try {
    const flags = ['--headless=new', '--no-first-run', '--no-default-browser-check', '--disable-background-networking',
      '--disable-extensions', '--hide-scrollbars', '--remote-allow-origins=*', '--remote-debugging-port=0',
      '--force-device-scale-factor=1', `--window-size=${opts.width},${opts.height}`, `--user-data-dir=${dir}`];
    // On Linux running as root, Chromium requires --no-sandbox. Non-root keeps sandboxing enabled.
    if (process.platform === 'linux' && process.getuid?.() === 0) flags.push('--no-sandbox');
    chrome = spawn(chromePath, flags, { stdio: 'ignore' });
    const port = await waitForChrome(dir, chrome);
    const result = await fetch(`http://127.0.0.1:${port}/json/new?about:blank`, { method: 'PUT' });
    if (!result.ok) throw new Error(`Chrome target creation failed HTTP ${result.status}`);
    const target = await result.json();
    cdp = new CDP(target.webSocketDebuggerUrl);
    await cdp.connect();
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await cdp.send('Network.enable');
    // Inline self-contained HTML into an isolated about:blank tab. Works even when
    // managed Chrome blocks file:// or localhost navigation, and requires no server.
    await cdp.send('Network.setBlockedURLs', { urls: ['http://*', 'https://*'] });
    await cdp.send('Emulation.setDeviceMetricsOverride', { width: opts.width, height: opts.height, deviceScaleFactor: 1, mobile: false });
    const tree = await cdp.send('Page.getFrameTree');
    await cdp.send('Page.setDocumentContent', {
      frameId: tree.frameTree.frame.id,
      html: fs.readFileSync(opts.scene, 'utf8')
    });
    const until = Date.now() + 15000;
    let ready = false;
    while (Date.now() < until) {
      try {
        ready = await cdp.eval('document.readyState === "complete" && typeof window.renderAt === "function"');
        if (ready) break;
      } catch { /* navigation still loading */ }
      await pause(100);
    }
    if (!ready) throw new Error('Scene must load and expose window.renderAt(t)');
    await cdp.eval('document.fonts ? document.fonts.ready.then(()=>true) : true');
    const ffArgs = ['-hide_banner', '-loglevel', 'error', '-y', '-f', 'image2pipe', '-framerate', String(opts.fps), '-vcodec', 'png', '-i', 'pipe:0'];
    if (opts.audio) ffArgs.push('-i', path.resolve(opts.audio));
    ffArgs.push('-map', '0:v:0');
    if (opts.audio) ffArgs.push('-map', '1:a:0');
    ffArgs.push('-c:v', 'libx264', '-preset', 'medium', '-crf', '19', '-pix_fmt', 'yuv420p', '-r', String(opts.fps));
    if (opts.audio) ffArgs.push('-c:a', 'aac', '-b:a', '192k', '-af', 'apad');
    ffArgs.push('-t', String(frames / opts.fps), '-movflags', '+faststart', opts.output);
    encoder = spawn('ffmpeg', ffArgs, { stdio: ['pipe', 'ignore', 'pipe'] });
    let ffErr = '';
    encoder.stderr.on('data', chunk => { ffErr += chunk.toString(); if (ffErr.length > 12000) ffErr = ffErr.slice(-12000); });
    const sampleIndices = new Map();
    if (opts.stills) {
      fs.mkdirSync(path.resolve(opts.stills), { recursive: true });
      for (const pct of [0, 25, 50, 75, 99]) sampleIndices.set(Math.min(frames - 1, Math.floor((frames - 1) * pct / 100)), pct);
    }
    for (let i = 0; i < frames; i++) {
      const t = i / opts.fps;
      await cdp.eval(`(async () => { await window.renderAt(${JSON.stringify(t)}); return true; })()`);
      const snap = await cdp.send('Page.captureScreenshot', { format: 'png', fromSurface: true, captureBeyondViewport: false });
      if (!snap.data) throw new Error(`Empty screenshot on frame ${i}`);
      const png = Buffer.from(snap.data, 'base64');
      if (sampleIndices.has(i)) fs.writeFileSync(path.resolve(opts.stills, `frame_${String(sampleIndices.get(i)).padStart(2,'0')}.png`), png);
      if (!encoder.stdin.write(png)) await once(encoder.stdin, 'drain');
      if (i === 0 || (i + 1) % Math.max(1, Math.round(frames / 5)) === 0 || i + 1 === frames) process.stderr.write(`Rendered ${i + 1}/${frames} frames\n`);
    }
    encoder.stdin.end();
    const [code] = await once(encoder, 'close');
    if (code !== 0) throw new Error(`FFmpeg failed with code ${code}: ${ffErr}`);
    if (!fs.existsSync(opts.output) || fs.statSync(opts.output).size < 1024) throw new Error('Output MP4 not created or too small');
    succeeded = true;
    process.stdout.write(JSON.stringify({ status: 'RENDERED_NOT_APPROVED', video: opts.output, frames, fps: opts.fps, duration: frames / opts.fps, width: opts.width, height: opts.height, audio: !!opts.audio }) + '\n');
  } finally {
    cdp?.close();
    if (encoder && encoder.exitCode === null) encoder.kill('SIGKILL');
    if (chrome && chrome.exitCode === null && chrome.signalCode === null) {
      chrome.kill('SIGKILL');
      await Promise.race([once(chrome, 'close'), pause(1400)]);
    }
    try { fs.rmSync(dir, { recursive: true, force: true, maxRetries: 10, retryDelay: 150 }); }
    catch (err) { process.stderr.write(`Temporary Chrome profile cleanup warning: ${err.message}\n`); }
    if (!succeeded && fs.existsSync(opts.output)) fs.rmSync(opts.output, { force: true });
  }
}

try {
  const opts = parseArgs(process.argv.slice(2));
  if (opts.help) { process.stdout.write(HELP); process.exit(0); }
  await run(opts);
} catch (err) {
  process.stderr.write(`RENDER ERROR: ${err.stack || err.message}\n`);
  process.exitCode = 1;
}
