import importlib.util
import json
import tempfile
import unittest
from pathlib import Path

SCRIPT_PATH = Path(__file__).resolve().parents[1] / "scripts" / "verify_campaign.py"
spec = importlib.util.spec_from_file_location("verify_campaign", SCRIPT_PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def manifest():
    return {
        "schema_version": 1,
        "campaign_id": "test-campagne",
        "market": ["FR"],
        "objective": "inscriptions",
        "production_method": "brand_owned",
        "creative_score": 82,
        "artifacts": dict(module.REQUIRED_ARTIFACTS),
        "claims": [
            {
                "id": "CL-01",
                "text": "La fonctionnalité de checklist est disponible",
                "status": "verified",
                "used_in_scripts": True,
                "evidence": "Vérifié sur la version de démonstration datée",
                "source_ref": "preuve-interne-2026-11-08"
            }
        ],
        "claim_free_reason": "",
        "clearances": {
            key: {"status": "pending", "evidence": "Contrôle en cours, document non reçu"}
            for key in module.REQUIRED_CLEARANCES
        },
        "final_video": None,
    }


class CampaignValidationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.data = manifest()
        for filename in self.data["artifacts"].values():
            (self.root / filename).write_text(
                "# Dossier de campagne\n\nContenu de test suffisamment long afin de vérifier les fichiers et la structure.",
                encoding="utf-8",
            )

    def tearDown(self):
        self.temp.cleanup()

    def save(self):
        (self.root / "manifest.json").write_text(json.dumps(self.data), encoding="utf-8")

    def test_preproduction_accepts_pending_rights_with_warnings(self):
        self.save()
        errors, warnings = module.validate_campaign(self.root, "preproduction")
        self.assertFalse(errors, errors)
        self.assertTrue(any("avant diffusion" in w for w in warnings))

    def test_publish_blocks_unverified_rights_and_missing_video(self):
        self.save()
        errors, _ = module.validate_campaign(self.root, "publish")
        self.assertTrue(any("music_rights" in e for e in errors))
        self.assertTrue(any("final_video" in e for e in errors))

    def test_publish_structure_passes_only_with_every_clearance_and_file(self):
        for key in self.data["clearances"]:
            self.data["clearances"][key] = {"status": "verified", "evidence": "Référence d'une revue humaine documentée"}
        self.data["final_video"] = "film.mp4"
        (self.root / "film.mp4").write_bytes(b"placeholder-for-structure-only")
        self.save()
        errors, warnings = module.validate_campaign(self.root, "publish")
        self.assertEqual(errors, [])
        self.assertTrue(any("humain" in w for w in warnings))

    def test_unverified_claim_used_in_script_fails_even_in_preproduction(self):
        self.data["claims"][0]["status"] = "pending"
        self.save()
        errors, _ = module.validate_campaign(self.root, "preproduction")
        self.assertTrue(any("sans vérification" in e for e in errors))

    def test_no_claims_requires_reason(self):
        self.data["claims"] = []
        self.save()
        errors, _ = module.validate_campaign(self.root)
        self.assertTrue(any("claim_free_reason" in e for e in errors))

    def test_path_traversal_rejected(self):
        self.data["artifacts"]["qa"] = "../private.md"
        self.save()
        errors, _ = module.validate_campaign(self.root)
        self.assertTrue(any("qa absent" in e for e in errors))

    def test_duplicate_claim_id_rejected(self):
        self.data["claims"].append(self.data["claims"][0].copy())
        self.save()
        errors, _ = module.validate_campaign(self.root)
        self.assertTrue(any("dupliqué" in e for e in errors))


if __name__ == "__main__":
    unittest.main()
