"""CLI contract tests and a short real Chrome -> FFmpeg integration render."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
RENDER = ROOT / 'scripts' / 'render_video.mjs'
SCENE = ROOT / 'examples' / 'motion-demo' / 'index.html'
PROBE = ROOT / 'scripts' / 'inspect_video.py'
AUDIO = ROOT / 'scripts' / 'generate_audio.py'


class RenderContractTests(unittest.TestCase):
    def test_renderer_help_documents_required_settings(self):
        result = subprocess.run(['node', str(RENDER), '--help'], capture_output=True, text=True, timeout=8)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn('--fps', result.stdout)
        self.assertIn('--duration', result.stdout)
        self.assertIn('--audio', result.stdout)

    def test_rejects_invalid_fps_before_launching_browser(self):
        result = subprocess.run(['node', str(RENDER), str(SCENE), '--fps', '0', '--output', 'x.mp4'], capture_output=True, text=True, timeout=8)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('fps', result.stderr.lower())

    @unittest.skipUnless(shutil.which('ffmpeg') and shutil.which('ffprobe') and shutil.which('node') and (shutil.which('chromium') or shutil.which('google-chrome')), 'Chrome, Node and ffmpeg required')
    def test_render_and_probe_mp4_with_original_audio(self):
        with tempfile.TemporaryDirectory() as tmp:
            dest = Path(tmp)
            wav = dest / 'original.wav'
            mp4 = dest / 'ad.mp4'
            gen = subprocess.run([sys.executable, str(AUDIO), '--output', str(wav), '--seconds', '1', '--seed', '7'], text=True, capture_output=True, timeout=12)
            self.assertEqual(gen.returncode, 0, gen.stderr)
            self.assertGreater(wav.stat().st_size, 1000)
            render = subprocess.run(['node', str(RENDER), str(SCENE), '--output', str(mp4), '--width', '320', '--height', '568', '--duration', '1', '--fps', '8', '--audio', str(wav), '--chrome', shutil.which('chromium') or shutil.which('google-chrome')], capture_output=True, text=True, timeout=55)
            self.assertEqual(render.returncode, 0, render.stderr[-2500:])
            self.assertGreater(mp4.stat().st_size, 2000)
            probe = subprocess.run([sys.executable, str(PROBE), str(mp4), '--width', '320', '--height', '568', '--fps', '8', '--duration', '1', '--require-audio', '--json'], capture_output=True, text=True, timeout=20)
            self.assertEqual(probe.returncode, 0, probe.stderr + probe.stdout)
            data = json.loads(probe.stdout)
            self.assertEqual(data['status'], 'PASS_TECHNIQUE')
            self.assertTrue(data['audio_present'])
            self.assertEqual(data['video_codec'], 'h264')


if __name__ == '__main__':
    unittest.main()
